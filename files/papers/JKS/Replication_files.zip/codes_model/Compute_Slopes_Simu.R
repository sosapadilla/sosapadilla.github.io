rm(list = ls())

library(tidyverse)
library(R.matlab)

# LOAD DATA ----
cat("\014") # clear the console
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #This if Using RSTUDIO
# setwd(getSrcDirectory()[1]) #This one doesn't rely on using RSTUDIO, will work in RSTUDIO if "sourced"

temp_from_matlab <- readMat("simulation_data.mat")
df.simu <- as.data.frame(temp_from_matlab)

#colnames(df.simu)
df.simu <- df.simu %>% 
  relocate(c("debt.ts.keep","hp.y.dev.ts.keep"), .after = quarter) %>%
  relocate(series.id, .before = quarter)


df.simu <- df.simu %>% 
  rename(
    quarter.id = quarter,
    GDP_pc = y.ts.keep,
    td_y_model = debt.ratio.ts.keep,
    debt = debt.ts.keep,
    real_rate_a = r.ts.keep,
    spread = spread.ts.keep,
    stoch_vol_a = r.vol.ts.keep,
    sdf = sdf.ts.keep,
    hp_ly = hp.y.dev.ts.keep,
    tby = tb.ts.keep,
    real_rate_q = r.ts.quarterly.keep,
    stoch_vol_q = r.vol.ts.quarterly.keep,
    r_vol_index = r.vol.index.ts.keep,
    r_index = r.index.ts.keep,
    yield_rf = yield.ts.keep)

# MANIPULATE LOADED DATA AND CREATE NEW VARIABLES ----
df.simu$r_vol_grid = (df.simu$stoch_vol_a+1)^(1/4)-1
# Put variables in percent (1 = 1% annualized)
df.simu$real_rate_a = 100*df.simu$real_rate_a
df.simu$stoch_vol_a = 100*df.simu$stoch_vol_a
df.simu$spread = 100*df.simu$spread
df.simu$real_rate_q = 100*df.simu$real_rate_q
df.simu$stoch_vol_q = 100*df.simu$stoch_vol_q
df.simu$yield_rf_q = 100*df.simu$yield_rf
df.simu$yield_rf_a = 4*df.simu$yield_rf_q

# Create new variables
df.simu <- df.simu %>%
  group_by(series.id) %>%
  mutate(stoch_vol_a_deviation = stoch_vol_a - mean(stoch_vol_a,na.rm = TRUE),
         rate_deviation_a = real_rate_a - mean(real_rate_a,na.rm = TRUE),
         rate_deviation_q = real_rate_q - mean(real_rate_q,na.rm = TRUE),
         sdf_deviation = sdf - mean(sdf,na.rm = TRUE),
         lag_td_y_model = dplyr::lag(td_y_model, 1),
         debt_mean_gdp_annual = debt*.25)

df.simu<-df.simu %>%
  group_by(series.id)%>%
  mutate(annualized_gdp=rollapply(GDP_pc,4,sum,align='right',fill=NA),
         spread_sd=rollapply(spread,3,sd,align='right',fill=NA))

df.simu<-df.simu %>%
  group_by(series.id)%>%
  mutate(debt_gdp = debt/annualized_gdp,
         delta_vol_a = stoch_vol_a - dplyr::lag(stoch_vol_a, 1),
         delta_vol_q = stoch_vol_q - dplyr::lag(stoch_vol_q, 1),
         delta_debt = 100*(dplyr::lead(debt_mean_gdp_annual, 1) - debt_mean_gdp_annual),
         delta_debt_ratio = 100*(dplyr::lead(td_y_model, 1) - td_y_model),
         delta_spread = spread - dplyr::lag(spread, 1),
         delta_yield_rf_a = yield_rf_a - dplyr::lag(yield_rf_a,1),
         delta_yield_rf_q = yield_rf_q - dplyr::lag(yield_rf_q,1),
         spread_slope_q = delta_spread/delta_yield_rf_q,
         spread_slope_a = delta_spread/delta_yield_rf_a,
         spread_slope_vol_a = delta_spread/delta_vol_a,
         spread_slope_vol_q = delta_spread/delta_vol_q,
         debt_slope_q = delta_debt_ratio/delta_yield_rf_q,
         debt_slope_a = delta_debt_ratio/delta_yield_rf_a,
         debt_slope_vol_q = delta_debt/delta_vol_q,
         debt_slope_vol_a = delta_debt/delta_vol_a,
         delta_y = GDP_pc - dplyr::lag(GDP_pc,1),
         issuance = (dplyr::lead(debt,1) - (1-0.0742)*debt),
         debt_to_issuance = debt/issuance,
         issuance_GDP = 100*(dplyr::lead(debt,1) - (1-0.0742)*debt)/(GDP_pc),
         issuance_slope = (issuance_GDP-dplyr::lag(issuance_GDP,1))/delta_yield_rf_a,
         issuance_slope_vol = (issuance_GDP-dplyr::lag(issuance_GDP,1))/delta_vol_a,
         delta_vol_grid = r_vol_grid - dplyr::lag(r_vol_grid,1),
         issuance_slope_vol_grid = (issuance_GDP-dplyr::lag(issuance_GDP,1))/(delta_vol_grid)* 
           dplyr::lag(r_vol_grid,1)/dplyr::lag(issuance_GDP,1),
         spread_slope_vol_grid = delta_spread/(delta_vol_grid)* 
           dplyr::lag(r_vol_grid,1)/dplyr::lag(spread,1),
         percent_change_vol = delta_vol_grid/dplyr::lag(r_vol_grid,1)
         )

df.simu <- df.simu %>%
  group_by(series.id) %>%
  mutate(
    dummy_rw_a = as.numeric(real_rate_a > mean(real_rate_a)),
    dummy_rw_a_high = as.numeric(real_rate_a > 1.5*mean(real_rate_a)),
    dummy_rw_q = as.numeric(real_rate_q > mean(real_rate_q)),
    dummy_rw_q_high = as.numeric(real_rate_q > 1.5*mean(real_rate_q)),
    dummy_rvol = as.numeric(stoch_vol_a > mean(stoch_vol_a)),
    dummy_rvol_high = as.numeric(stoch_vol_a > 1.5*mean(stoch_vol_a)),
    dummy_rvol_high_model = as.numeric(log(stoch_vol_a) > 1.15*mean(log(stoch_vol_a))),
    dummy_vix = as.numeric(sdf < mean(sdf,na.rm = TRUE))
  )

df.simu$r_vol_index_factor <-as.factor(df.simu$r_vol_index)
df.simu$r_index_factor <-as.factor(df.simu$r_index)

y.1 <- quantile(df.simu$GDP_pc,c(1/3))
y.2 <- quantile(df.simu$GDP_pc,c(2/3))

df.simu <- df.simu %>%
  mutate(vol_group = ifelse(r_vol_index<4,1,
                             ifelse(r_vol_index>4 ,3,2)),
         r_group= ifelse(yield_rf_q<1,1,
                         ifelse(yield_rf_q>1 ,3,2)),
         y_group= ifelse(GDP_pc<y.1,1,
                         ifelse(GDP_pc>y.2 ,3,2)),
         y_group_median= ifelse(GDP_pc<1,1,2),
         delta_y_group = ifelse(delta_y<0,1,
                                ifelse(delta_y>0,3,2)))

SD_GDP <- sd(df.simu$GDP_pc)
MEAN_GDP<- mean(df.simu$GDP_pc)

##REPORT THE STATISTICS OF INTEREST: -----

#1) SPREAD SLOPE
Slope <- df.simu%>%  
  filter(abs(delta_yield_rf_a) > .05)%>%
  filter(abs(delta_yield_rf_a) < .25)%>%
  filter(abs(delta_debt)<0.0001)%>%
  filter(GDP_pc >= MEAN_GDP-2*SD_GDP)%>%
  filter(GDP_pc <= MEAN_GDP+2*SD_GDP)%>%
  group_by(r_vol_index)%>%
  summarise(
    Obs=n(),
    Spread.slope.Annual = mean(spread_slope_a, na.rm = TRUE),
    SD.slope.A = sd(spread_slope_a, na.rm = TRUE),
  )

#These are the computations of the spread slope at mean, low and high volatility:
Spread_slope_report <- Slope%>%filter(r_vol_index %in% c("2","4","6"))
view(Spread_slope_report)


#2) ISSUANCE SLOPE
Issuance.Slope <- df.simu%>%  
   filter(abs(delta_yield_rf_a) > .05)%>%
   filter(abs(delta_yield_rf_a) < .25)%>%
  filter(GDP_pc >= MEAN_GDP-2*SD_GDP)%>%
  filter(GDP_pc <= MEAN_GDP+2*SD_GDP)%>%
  group_by(r_vol_index)%>%
  summarise(
    Obs=n(),
    Mean = mean(issuance_slope, na.rm = TRUE),
    SD= sd(issuance_slope, na.rm = TRUE),
  )

#These are the computations of the issuance slope at mean, low and high volatility:
Issuance_slope_report <- Issuance.Slope%>%filter(r_vol_index %in% c("2","4","6"))
view(Issuance_slope_report)
