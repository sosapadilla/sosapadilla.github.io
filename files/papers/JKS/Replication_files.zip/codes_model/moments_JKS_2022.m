%% Code to simulate JKS Model ---------------------------------------------
% File to simulate the moments reported in Johri, Khan, and Sosa-Padilla's 
% "Interest Rate Uncertainty and Sovereign Default Risk" (2022) -- 2nd
% round R&R at the JIE
%
% Some usage notes are found throughout the code, but mainly in companion
% README file.
% -------------------------------------------------------------------------

tic
clc

indicator_load = 10;

if indicator_load > 0.5
    
    clear
   
    load graphs_data_sim_dss.txt
    load graphs_def_per_dss.txt
    load graphs_param_dss.txt
    load graphs_delta.txt
    load graphs_r_grid_dss.txt
    load graphs_y_grid_dss.txt
    load graphs_r_vol_grid_dss.txt
    load graphs_expected_sdf_matrix.txt
    
    data_sim = graphs_data_sim_dss;
    def_per = graphs_def_per_dss;
    param = graphs_param_dss;
    delta = graphs_delta;
    r_grid = graphs_r_grid_dss;
    y_grid = graphs_y_grid_dss;
    r_vol_grid = graphs_r_vol_grid_dss;
    expected_sdf = graphs_expected_sdf_matrix;
    
    y_num = length(y_grid);
    r_vol_num = length(r_vol_grid);
    r_num = length(r_grid)/r_vol_num;
    
    r_grid_matrix = reshape(r_grid, r_num,r_vol_num);
    
    expected_sdf_matrix = reshape(expected_sdf, y_num,r_num,r_vol_num);
    
    %So, the different values of r_level are on the rows, and r_vol changes in the columns
    
else
    
    
    clearvars -except data_sim def_per param delta
    
end %ends indicator_load loop.

rw = 0.01; %mean world interest rate
coupon_rw = (rw+delta)/(1+rw);

per_num = param(1);  %HOW MANY PERIODS IN EACH SAMPLE
n = param(2);        %HOW MANY SAMPLES

y = zeros(per_num, n);
b = zeros(per_num, n);
q = zeros(per_num, n);
qdef = zeros(per_num, n); %we don't need this; qdef=0 all the time.
c = zeros(per_num, n);
tb = zeros(per_num, n);
e = zeros(per_num, n);
d = zeros(per_num, n);
r = zeros(per_num, n);
b_next = zeros(per_num-1, n);
q_def_free = zeros(per_num, n);

for i=1:n
    y(:,i) = data_sim((i-1)*per_num+1:i*per_num,1);
    b(:,i) = data_sim((i-1)*per_num+1:i*per_num,2);
    q(:,i) = data_sim((i-1)*per_num+1:i*per_num,3);
    qdef(:,i) = data_sim((i-1)*per_num+1:i*per_num,4);
    c(:,i) = data_sim((i-1)*per_num+1:i*per_num,5);
    tb(:,i) = data_sim((i-1)*per_num+1:i*per_num,6);
    e(:,i) = data_sim((i-1)*per_num+1:i*per_num,7);
    d(:,i) = data_sim((i-1)*per_num+1:i*per_num,8)-1;
    r(:,i) = data_sim((i-1)*per_num+1:i*per_num,9);
    q_def_free(:,i) = data_sim((i-1)*per_num+1:i*per_num,10);
    i_y_current(:,i) = data_sim((i-1)*per_num+1:i*per_num,11);
    i_r_current(:,i) = data_sim((i-1)*per_num+1:i*per_num,12);
    i_vol_current(:,i) = data_sim((i-1)*per_num+1:i*per_num,13);
    
end

for i_sample=1:n
    for i_period =1:per_num
        sdf(i_period,i_sample) = expected_sdf_matrix(i_y_current(i_period,i_sample),...
            i_r_current(i_period,i_sample), i_vol_current(i_period,i_sample));
    end
end

excl_periods = find(data_sim(:,7)>1); %not being used.
b_next = b(2:per_num,:);

for j=1:per_num
    for i=1:n
        coupon(j,i) = (rw+delta)/(1+rw);
    end
end

%CREATE OUTPUT SERIES
num = max(1000,n); %HOW MANY PERIODS IN EACH SUBSAMPLE

%Burn in the initial observations
last_y = y(per_num - num+1:per_num,:);
last_b = b(per_num - num+1:per_num,:);

last_q = q(per_num - num+1:per_num,:);
last_c = c(per_num - num+1:per_num,:);  
last_tb= tb(per_num - num+1:per_num,:); 
last_e = e(per_num - num+1:per_num,:);
last_d = d(per_num - num+1:per_num,:);
last_r = r(per_num - num+1:per_num,:);
last_b_to_y= 0.25 * last_b./last_y;
last_coupon = coupon(per_num - num+1:per_num,:);
last_q_def_free = q_def_free(per_num - num+1:per_num,:);

last_i_y = i_y_current(per_num - num+1:per_num,:);
last_i_r = i_r_current(per_num - num+1:per_num,:);
last_i_vol = i_vol_current(per_num - num+1:per_num,:);
last_sdf = sdf(per_num - num+1:per_num,:);

last_yield_long = (last_coupon./last_q -delta);
last_yield_long_rf = last_coupon./last_q_def_free-delta;

for j=1:num
    for i=1:n
        last_duration(j,i) = (((1-delta).*last_q(j,i) +last_coupon(j,i))./(last_q(j,i)))./...
            (((1-delta).*last_q(j,i) +last_coupon(j,i))./(last_q(j,i))-1+delta);
    end
end

last_duration_1 = (1+last_yield_long)./(last_yield_long+delta);

last_spread_annual = ( last_yield_long-last_yield_long_rf) *4;
last_spread_quarterly = ( last_yield_long-last_yield_long_rf) ;

last_spread_annual_rw = ((1+last_yield_long)./ (1+rw)).^4 - 1;
last_spread_quarterly_rw = ( (1+last_yield_long)./ (1+rw) ).^1 - 1;

last_spread_annual_rt = ((1+last_yield_long)./ (1+last_r)).^4 - 1;
last_spread_quarterly_rt = ( (1+last_yield_long)./ (1+last_r) ).^1 - 1;


%% Detrending:

lambda = 1600;

y_trend = hpfilter(log(last_y),lambda);      
c_trend = hpfilter(log(last_c), lambda);     
tb_trend = hpfilter(last_tb, lambda);        
spread_annual_trend = hpfilter(last_spread_annual, lambda);  
spread_quarterly_trend = hpfilter(last_spread_quarterly, lambda);
spread_annual_rw_trend = hpfilter(last_spread_annual_rw, lambda);
spread_annual_rt_trend = hpfilter(last_spread_annual_rt, lambda);
r_trend = hpfilter(log(last_r), lambda);           
b_to_y_trend = hpfilter(last_b_to_y, lambda);

%COMPUTE DEVIATIONS FROM TREND
y_dev = log(last_y)- y_trend;
c_dev = log(last_c) - c_trend;
tb_dev = last_tb - tb_trend;
spread_annual_dev = last_spread_annual - spread_annual_trend;
spread_quarterly_dev = last_spread_quarterly - spread_quarterly_trend;
spread_annual_rw_dev = last_spread_annual_rw - spread_annual_rw_trend;
spread_annual_rt_dev = last_spread_annual_rt - spread_annual_rt_trend;
r_dev = log(last_r) - r_trend;
b_to_y_dev=last_b_to_y - b_to_y_trend;

%% Compute moments for Argentina for 1991-2001 (32 Quarters before a default)
per_immediately_after = -1;
per_before=104;  % quarters before a default
per_after=-1;   % quarters after a default
sample_size = per_before+per_after+1; %sample includes the def period, per_before quarters before and per_after quarters after

max_num_def = max(sum(last_d));

% n is the number of samples (= 500, unless modified somewhere)
num_observations_vector = zeros(n,1); %NUMBER OF OBSERVATIONS PER SAMPLE (AN OBSERVATION
% IS A DEFAULT EPISODE WITH SUFFICIENT PERIODS BEFORE THE DEFAULT AND NO
% EXCLUSION IN BETWEEN

def_per_matrix = zeros(max_num_def,n); %MATRIX OF DEFAULT PERIODS SATISFYING
%THE ABOVE RESTRICTION. THIS MATRIX WILL HAVE THE 'LOCATION' OF THE
%DEFAULTS EVENTS.

index_acum = 0; %INDEX OF ACUMULATED NUMBER OF DEFAULT EPISODES

for i = 1:n
    def_num = sum(d(:,i)); %# of defaults in sample i
    def_num_last = sum(last_d(:,i)); %# of defaults in sample i, after trimming
    if def_num_last>0
                
        %here... i need to define def_periods_last.. because we only use those!        
        
        def_periods = def_per(index_acum+1:index_acum+def_num);  %VECTOR OF DEFAULT PERIODS of each sample 'i' of the n samples!
        deff=find(def_periods>(per_num - num)); % this is to take into account only the last num periods.
        def_periods_last = def_periods(deff)-(per_num-num);
        
        
        interperiods = zeros(def_num_last,1);
        interperiods(1) = def_periods_last(1);             %SEPARATION BETWEEN DEFAULT PERIODS
        interperiods(2:def_num_last)= diff(def_periods_last);   %SEPARATION BETWEEN DEFAULT PERIODS
        
        indices = find(interperiods>(sample_size + 1) &...
            def_periods_last(def_num_last)<=(num-per_after) &...
            last_e(min(max(def_periods_last - per_before -1,1),num),i)<2);
        
        
        num_observations_vector(i) = length(indices);        %STORE THE NUMBER OF SUCH SAMPLES
        if length(indices)>0
            def_per_matrix(1:length(indices),i) = def_periods_last(indices);
        end
    end
    
    
    index_acum = index_acum + def_num;
end

num_observations = sum(num_observations_vector);

std_y_vector = zeros(num_observations,1);
std_c_vector = zeros(num_observations,1);
std_tb_vector = zeros(num_observations,1);
std_spread_vector = zeros(num_observations,1);
std_spread_rw_vector = zeros(num_observations,1);
std_spread_rt_vector = zeros(num_observations,1);
std_spread_dev_vector = zeros(num_observations,1);
std_spread_rw_dev_vector = zeros(num_observations,1);
std_spread_rt_dev_vector = zeros(num_observations,1);
std_b_to_y_vector = zeros(num_observations,1);
std_r_vector = zeros(num_observations,1);

corr_y_c_vector = zeros(num_observations,1);
corr_y_tb_vector = zeros(num_observations,1);
corr_y_r_vector = zeros(num_observations,1);

corr_spread_y_vector = zeros(num_observations,1);
corr_spread_level_y_vector = zeros(num_observations,1);
corr_spread_rw_y_vector = zeros(num_observations,1);
corr_spread_rt_y_vector = zeros(num_observations,1);
corr_spread_rw_level_y_vector = zeros(num_observations,1);
corr_spread_rt_level_y_vector = zeros(num_observations,1);

corr_spread_c_vector = zeros(num_observations,1);
corr_spread_r_vector = zeros(num_observations,1);
corr_spread_tb_vector = zeros(num_observations,1);
corr_y_ylag_vector = zeros(num_observations,1);

mean_b_vector = zeros(num_observations,1);
mean_duration_vector = zeros(num_observations,1);
mean_b_to_y_vector = zeros(num_observations,1);
mean_spread_vector = zeros(num_observations,1);
mean_spread_rw_vector = zeros(num_observations,1);
mean_spread_rt_vector = zeros(num_observations,1);
median_spread_vector = zeros(num_observations,1);

index_observation = 1;

for i=1:n
    for j=1:num_observations_vector(i)
        
        duration_vector = last_duration_1(def_per_matrix(j,i) - per_before:def_per_matrix(j,i)+ per_after,i);
        
        spread_annual_vector = last_spread_annual(def_per_matrix(j,i)- per_before:def_per_matrix(j,i) + per_after,i);
        yield_vector = last_yield_long_rf(def_per_matrix(j,i)- per_before:def_per_matrix(j,i) + per_after,i);
                
        spread_annual_rw_vector = last_spread_annual_rw(def_per_matrix(j,i)- per_before:def_per_matrix(j,i) + per_after,i);
        spread_annual_rt_vector = last_spread_annual_rt(def_per_matrix(j,i)- per_before:def_per_matrix(j,i) + per_after,i);
                
        y_vector = last_y(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        c_vector = last_c(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        tb_vector = last_tb(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        r_vector = last_r(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        b_vector = last_b(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        b_to_y_vector = last_b_to_y(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        
        i_y_vector = last_i_y(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        i_r_vector = last_i_r(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        i_vol_vector = last_i_vol(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        sdf_vector = last_sdf(def_per_matrix(j,i) - per_before:def_per_matrix(j,i) +per_after,i);
        
        hp_y = hpfilter(log(y_vector),lambda); 
        hp_c = hpfilter(log(c_vector),lambda); 
        hp_tb = hpfilter(tb_vector,lambda);    
        hp_r = hpfilter(log(r_vector),lambda); 
        hp_b_to_y = hpfilter(b_to_y_vector,lambda);
        hp_spread_annual = hpfilter(spread_annual_vector,lambda);    
        hp_spread_annual_rw = hpfilter(spread_annual_rw_vector,lambda); 
        hp_spread_annual_rt = hpfilter(spread_annual_rt_vector,lambda); 
        
        dev_y = log(y_vector) - hp_y;
        dev_c = log(c_vector) - hp_c;
        dev_tb = tb_vector - hp_tb;
        dev_r = log(r_vector) - hp_r;
        dev_b_to_y = b_to_y_vector - hp_b_to_y; 
        dev_spread_annual = spread_annual_vector - hp_spread_annual;
        dev_spread_annual_rw = spread_annual_rw_vector - hp_spread_annual_rw;
        dev_spread_annual_rt = spread_annual_rt_vector - hp_spread_annual_rt;
        
        std_spread_dev_vector(index_observation) = nanstd(dev_spread_annual);
        std_spread_rw_dev_vector(index_observation) = nanstd(dev_spread_annual_rw);
        std_spread_rt_dev_vector(index_observation) = nanstd(dev_spread_annual_rt);
        std_spread_vector(index_observation) = nanstd(spread_annual_vector);
        std_spread_rw_vector(index_observation) = nanstd(spread_annual_rw_vector);
        std_spread_rt_vector(index_observation) = nanstd(spread_annual_rt_vector);
        std_c_vector(index_observation) = nanstd(dev_c);
        std_y_vector(index_observation) = nanstd(dev_y);
        std_tb_vector(index_observation) = nanstd(dev_tb);
        std_r_vector(index_observation) = nanstd(dev_r);
        std_b_to_y_vector(index_observation) = nanstd(dev_b_to_y);        
        
        matrix = corrcoef(dev_y, dev_c);
        corr_y_c_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_y, dev_tb);
        corr_y_tb_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_y, dev_r);
        corr_y_r_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_spread_annual, dev_y);
        corr_spread_y_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(spread_annual_vector, dev_y);
        corr_spread_level_y_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_spread_annual_rw, dev_y);
        corr_spread_rw_y_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_spread_annual_rt, dev_y);
        corr_spread_rt_y_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(spread_annual_rw_vector, dev_y);
        corr_spread_rw_level_y_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(spread_annual_rt_vector, dev_y);
        corr_spread_rt_level_y_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_spread_annual, dev_c);
        corr_spread_c_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_spread_annual, dev_tb);
        corr_spread_tb_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_spread_annual, dev_r);
        corr_spread_r_vector(index_observation) = matrix(1,2);
        
        matrix = corrcoef(dev_spread_annual_rw, dev_r);
        corr_spread_rw_vector(index_observation) = matrix(1,2);

        matrix = corrcoef(dev_spread_annual_rt, dev_r);
        corr_spread_rt_vector(index_observation) = matrix(1,2);

        matrix = corrcoef(dev_spread_annual_rt, dev_spread_annual);
        corr_spread_both(index_observation) = matrix(1,2);
        
        mean_b_vector(index_observation) = nanmean(b_vector);
        mean_duration_vector(index_observation) = nanmean(duration_vector);
        mean_b_to_y_vector(index_observation) = nanmean(b_to_y_vector);
        median_b_to_y_vector(index_observation) = nanmedian(b_to_y_vector);
        mean_spread_vector(index_observation) = nanmean(spread_annual_vector);
        median_spread_vector(index_observation) = nanmedian(spread_annual_vector);
        mean_spread_rw_vector(index_observation) = nanmean(spread_annual_rw_vector);
        mean_spread_rt_vector(index_observation) = nanmean(spread_annual_rt_vector);
        
        y_ts(index_observation,:)=y_vector; % this is quarterly GDP
        hp_y_dev_ts(index_observation,:)=dev_y;
        c_ts(index_observation,:)=c_vector;
        b_ts(index_observation,:)=b_vector;
        b_to_y_ts(index_observation,:)=b_to_y_vector; %already divided by annual GDP
        spread_ts(index_observation,:) =spread_annual_vector;
        yield_ts(index_observation,:) =yield_vector;
        tb_ts(index_observation,:) =tb_vector;
        spreadrw_ts(index_observation,:) =spread_annual_rw_vector;
        spreadrt_ts(index_observation,:) =spread_annual_rt_vector;
        
        r_ts(index_observation,:)=(1+r_vector).^4-1;
        r_ts_quarterly(index_observation,:)=r_vector;
        r_index_ts(index_observation,:)=i_r_vector;
        r_vol_index_ts(index_observation,:)=i_vol_vector;
        r_vol_ts(index_observation,:)=(1+exp(r_vol_grid(i_vol_vector))).^4-1;
        r_vol_ts_quarterly(index_observation,:)=r_vol_grid(i_vol_vector);
        sdf_ts(index_observation,:)=sdf_vector;
        
        
        index_observation = index_observation+1;
    end
end

quarter_a(:,1)=1:size(y_ts,2);

n_samples = size(y_ts,1);

quarter_b(:,1)=ones(n_samples,1);

quarter=kron(quarter_b,quarter_a);

series_id1=kron(1:n_samples,ones(size(y_ts,2),1));
series_id = series_id1(:);

y_ts_keep = y_ts(1:n_samples,:)';
y_ts_keep = y_ts_keep(:);

hp_y_dev_ts_keep = hp_y_dev_ts(1:n_samples,:)';
hp_y_dev_ts_keep = hp_y_dev_ts_keep(:);

spread_ts_keep = spread_ts(1:n_samples,:)';
spread_ts_keep = spread_ts_keep(:);

yield_ts_keep = yield_ts(1:n_samples,:)';
yield_ts_keep = yield_ts_keep(:);

debt_ts_keep = -b_ts(1:n_samples,:)';
debt_ts_keep = debt_ts_keep(:);

debt_ratio_ts_keep = -b_to_y_ts(1:n_samples,:)';
debt_ratio_ts_keep = debt_ratio_ts_keep(:);

tb_ts_keep = tb_ts(1:n_samples,:)';
tb_ts_keep = tb_ts_keep(:);

r_ts_keep = r_ts(1:n_samples,:)';
r_ts_keep = r_ts_keep(:);

r_ts_quarterly_keep = r_ts_quarterly(1:n_samples,:)';
r_ts_quarterly_keep = r_ts_quarterly_keep(:);

r_vol_ts_quarterly_keep = r_vol_ts_quarterly(1:n_samples,:)';
r_vol_ts_quarterly_keep = r_vol_ts_quarterly_keep (:);

r_vol_ts_keep = r_vol_ts(1:n_samples,:)';
r_vol_ts_keep = r_vol_ts_keep(:);

r_vol_index_ts_keep = r_vol_index_ts(1:n_samples,:)';
r_vol_index_ts_keep = r_vol_index_ts_keep(:);

r_index_ts_keep = r_index_ts(1:n_samples,:)';
r_index_ts_keep= r_index_ts_keep(:);

sdf_ts_keep = sdf_ts(1:n_samples,:)';
sdf_ts_keep = sdf_ts_keep(:);

% The line below saves the data in a .mat file which is easy to open in R:
save simulation_data series_id quarter y_ts_keep spread_ts_keep debt_ratio_ts_keep debt_ts_keep ...
    tb_ts_keep r_ts_keep r_vol_ts_keep sdf_ts_keep hp_y_dev_ts_keep ...
    r_ts_quarterly_keep r_vol_ts_quarterly_keep r_vol_index_ts_keep r_index_ts_keep yield_ts_keep

%Get rid of the most extreme .05% on each side of the distribution of
%spreads.

spread_995 = quantile(mean_spread_vector,.995);
spread_005 = quantile(mean_spread_vector,.005);

no_outlier_position = find(mean_spread_vector <= spread_995 & mean_spread_vector >= spread_005);

std_y_no_outlier = std_y_vector(no_outlier_position);
std_c_no_outlier = std_c_vector(no_outlier_position);
std_tb_no_outlier = std_tb_vector(no_outlier_position);
std_spread_no_outlier = std_spread_vector(no_outlier_position);
std_spread_rw_no_outlier = std_spread_rw_vector(no_outlier_position);
std_spread_rt_no_outlier = std_spread_rt_vector(no_outlier_position);
std_spread_dev_no_outlier = std_spread_dev_vector(no_outlier_position);
std_spread_rw_dev_no_outlier = std_spread_rw_dev_vector(no_outlier_position);
std_spread_rt_dev_no_outlier = std_spread_rt_dev_vector(no_outlier_position);

std_b_to_y_no_outlier = std_b_to_y_vector(no_outlier_position);
std_r_no_outlier = std_r_vector(no_outlier_position);

corr_y_c_no_outlier = corr_y_c_vector(no_outlier_position);
corr_y_tb_no_outlier = corr_y_tb_vector(no_outlier_position);
corr_y_r_no_outlier = corr_y_r_vector(no_outlier_position);
corr_spread_y_no_outlier = corr_spread_y_vector(no_outlier_position);
corr_spread_rw_y_no_outlier = corr_spread_rw_y_vector(no_outlier_position);
corr_spread_rt_y_no_outlier = corr_spread_rt_y_vector(no_outlier_position);

corr_spread_c_no_outlier = corr_spread_c_vector(no_outlier_position);
corr_spread_r_no_outlier = corr_spread_r_vector(no_outlier_position);
corr_spread_rw_no_outlier = corr_spread_rw_vector(no_outlier_position);
corr_spread_rt_no_outlier = corr_spread_rt_vector(no_outlier_position);

corr_spread_tb_no_outlier = corr_spread_tb_vector(no_outlier_position);

corr_spread_both_no_outlier = corr_spread_both(no_outlier_position);

mean_b_to_y_no_outlier = mean_b_to_y_vector(no_outlier_position);
median_b_to_y_no_outlier = median_b_to_y_vector(no_outlier_position);
mean_spread_no_outlier = mean_spread_vector(no_outlier_position);
mean_spread_rw_no_outlier = mean_spread_rw_vector(no_outlier_position);
mean_spread_rt_no_outlier = mean_spread_rt_vector(no_outlier_position);
mean_b_no_outlier = mean_b_vector(no_outlier_position);
mean_duration_no_outlier = mean_duration_vector(no_outlier_position);
median_spread_no_outlier = median_spread_vector(no_outlier_position);


num_simulations = length(std_y_no_outlier);

num_simulations = min (num_simulations, 500);


fprintf(' \n')
fprintf('Moments reported in Table 3 (Model Fit) \n')
fprintf('======================================= \n')
fprintf(' *Targeted Moments* \n')
fprintf('Mean Debt-to-Income            =%4.0f \n',-100*nanmean(mean_b_to_y_no_outlier(1:num_simulations)))
fprintf('Mean Spread                    = %2.1f \n',100*nanmean(mean_spread_no_outlier(1:num_simulations)))
fprintf('SD of Spread                   = %2.1f \n',100*nanmean(std_spread_no_outlier(1:num_simulations)))
fprintf(' \n')
fprintf(' *Non-Targeted Moments* \n')
ratio_c_y = nanmean(std_c_no_outlier(1:num_simulations))/nanmean(std_y_no_outlier(1:num_simulations));
fprintf('SD(c)/ SD(y)                   = %2.1f \n', ratio_c_y)
fprintf('corr(c,y)                      = %2.1f \n',nanmean(corr_y_c_no_outlier(1:num_simulations)))
fprintf('corr(R_s,y)                    = %2.1f \n',nanmean(corr_spread_y_no_outlier(1:num_simulations)))
fprintf(' \n')

fprintf(['** Stats based on ',num2str(num_simulations),' samples of ',num2str(per_before),...
    ' obs. before a default and w/o outliers. \n'])


toc
