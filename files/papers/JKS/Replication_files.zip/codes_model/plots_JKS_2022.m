%% plots_JKS_2022.m -------------------------------------------------------
%
% This file must be located in the same folder where the results from the
% computation of the model are stored.
%
% This file reproduces Figures 1, 2 and 3 in the draft, as well as Figure
% A2 in the Appendix. 
%
% Figure A1 (while not replicated here) is a paralell
% with Figure 1 and can be reproduce using this code *but* using underlying
% data coming from the model discussed in Appendix B.
%
% Figure A3 only uses data, and instructions on how to replicate it can be
% found in the README file.
%
%
% Some usage notes are found throughout the code, but mainly in companion
% README file.
% -------------------------------------------------------------------------

clear
close all
clc

load graphs_b_grid_dss.txt
load graphs_y_grid_dss.txt
load graphs_r_grid_dss.txt
load graphs_v_dss.txt
load graphs_q_dss.txt
load graphs_q_def_free.txt
load graphs_q_def_free_dss.txt
load graphs_default_dss.txt
load graphs_b_next_dss.txt
load graphs_dev_dss.txt
load graphs_q_paid_dss.txt
load graphs_r_vol_grid_dss.txt
load graphs_trans_matrix_y.txt
load graphs_trans_matrix_r.txt
load graphs_trans_matrix_r_vol.txt
load graphs_consumption_dss.txt
load graphs_delta.txt

b_grid = graphs_b_grid_dss;
y_grid = graphs_y_grid_dss;
r_grid = graphs_r_grid_dss;
r_vol_grid = graphs_r_vol_grid_dss;
v = graphs_v_dss;
q = graphs_q_dss;
q_def_free = graphs_q_def_free;
q_def_free_new = graphs_q_def_free_dss;
default = graphs_default_dss;
b_next = graphs_b_next_dss;
dev = graphs_dev_dss;
q_paid = graphs_q_paid_dss;
trans_matrix_y = graphs_trans_matrix_y;
trans_matrix_r = graphs_trans_matrix_r;
trans_matrix_r_vol = graphs_trans_matrix_r_vol;
consumption = graphs_consumption_dss;
delta = graphs_delta;

b_num = length(b_grid);
y_num = length(y_grid);
r_num = length(r_grid)/length(r_vol_grid);
r_vol_num = length(r_vol_grid);

r_grid_matrix=reshape(r_grid, r_vol_num, r_num);

v0_matrix = zeros(b_num, y_num, r_num, r_vol_num);
v1_matrix = zeros(b_num, y_num, r_num, r_vol_num);
v_matrix = zeros(b_num, y_num, r_num, r_vol_num);
default_matrix = zeros(b_num, y_num, r_num, r_vol_num);
q_matrix = zeros(b_num, y_num, r_num, r_vol_num);
q_def_free_matrix = zeros(y_num, r_num, r_vol_num);
q_arellano_matrix = zeros(b_num, y_num);
v0_arellano_matrix = zeros(b_num, y_num);
v1_arellano_matrix = zeros(b_num, y_num);
v_arellano_matrix = zeros(b_num, y_num);

transition_matrix_y = zeros(y_num, y_num);

cons0_matrix = zeros(b_num, y_num, r_num, r_vol_num);
cons1_matrix = zeros(b_num, y_num, r_num, r_vol_num);
cons_matrix = zeros(b_num, y_num, r_num, r_vol_num);
b_next_matrix = zeros(b_num, y_num, r_num, r_vol_num);
b_next_arellano_matrix = zeros(b_num,y_num);
dev_matrix = zeros(b_num, y_num, r_num, r_vol_num);
q_paid_matrix = zeros(b_num, y_num, r_num, r_vol_num);
tb_matrix = zeros(b_num, y_num, r_num, r_vol_num);
q_def_free_new_matrix = zeros(b_num, y_num, r_num, r_vol_num);

for i_vol = 1:r_vol_num
    for i_r = 1:r_num
        for i_y = 1:y_num
            q_def_free_matrix(i_y, i_r, i_vol) = q_def_free((i_vol-1)*r_num*y_num+ (i_r-1)*y_num+i_y);
            
            for i_b = 1:b_num
                
                v0_matrix(i_b, i_y, i_r, i_vol) = v((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b,2);
                v1_matrix(i_b, i_y, i_r, i_vol) = v((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b,3);
                v_matrix(i_b, i_y, i_r, i_vol) = v((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b,1);
                default_matrix(i_b, i_y, i_r, i_vol) = default((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b);
                q_matrix(i_b, i_y, i_r, i_vol) = q((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b);
                q_paid_matrix(i_b, i_y, i_r, i_vol) = q_paid((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b);
                b_next_matrix(i_b, i_y, i_r, i_vol) = b_next((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b);
                dev_matrix(i_b, i_y, i_r, i_vol) = dev((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b);
                cons0_matrix(i_b, i_y, i_r, i_vol) = consumption((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b,2);
                cons1_matrix(i_b, i_y, i_r, i_vol) = consumption((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b,3);
                cons_matrix(i_b, i_y, i_r, i_vol) = consumption((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b,1);
                q_def_free_new_matrix(i_b,i_y, i_r, i_vol) = q_def_free_new((i_vol-1)*r_num*y_num*b_num+ (i_r-1)*y_num*b_num+(i_y-1)*b_num + i_b,1);
                
            end
        end
    end
end

for i=1:y_num
    for j=1:y_num
        transition_matrix_y(i, j) = trans_matrix_y((i-1)*y_num + j,1);
    end
end

rw=0.01;
for j=1:r_vol_num
    for i=1:r_num
        coupon_matrix(i,j) = (rw+delta)/(1+rw);
    end
end

for i_vol = 1:r_vol_num
    for i_r = 1:r_num
        for i_r_tomorrow = 1:r_num
            
            pointer = (i_vol-1)*r_num*r_num+ (i_r-1)*r_num+ i_r_tomorrow;
            
            tm_r(i_r,i_r_tomorrow,i_vol)= trans_matrix_r(pointer,1);
        end
    end
end


%set locations of mean values:

i_r_mean = floor(r_num/2)+1;
i_r_vol_mean = floor(r_vol_num/2)+1;
i_y_mean = floor(y_num/2)+1;

aux = -.44 *4;
aa=(b_grid-aux*ones(b_num,1)).^2;
[~, i_b_mean] = min(aa);



%% Savings functions grpahs

% This gets rid of the default part of the policy function:
indice_1 = find(b_next_matrix==-4);
b_next_matrix_plot=b_next_matrix;
b_next_matrix_plot(indice_1)=NaN;

% Borrowing by vol:


%This is figure A2-(a) in the Appendix:

i_y_plot = i_y_mean;
i_r_vol_plot =2;

weight = 1;
i_r_low=2;
vector_1 =(squeeze(-b_grid(b_next_matrix_plot(:, i_y_plot, i_r_low, i_r_vol_plot))/4) * weight + ...
    squeeze(-b_grid(b_next_matrix_plot(:, i_y_plot, i_r_low+1, i_r_vol_plot))/4) * (1-weight));

vector_1(vector_1==0)=nan;

i_r_high = 6;
vector_2 =(squeeze(-b_grid(b_next_matrix_plot(:, i_y_plot, i_r_high, i_r_vol_plot))/4) * weight + ...
    squeeze(-b_grid(b_next_matrix_plot(:, i_y_plot, i_r_high-1, i_r_vol_plot))/4) * (1-weight));

vector_2(vector_2==0)=nan;

figure
H = plot(-b_grid/4, [vector_1 vector_2 -b_grid/4]);
set(gca,'FontSize',14,'TickLabelInterpreter','latex')
set(H(1), 'LineStyle','--','LineWidth',3,'MarkerSize',.1, 'Color','r')
set(H(2), 'LineStyle','-','LineWidth',3,'MarkerSize',.1, 'Color','b')
set(H(3), 'LineStyle',':','LineWidth',1,'MarkerSize',.1, 'Color','k')
% set(H(4), 'LineStyle','-','LineWidth',1,'MarkerSize',.1, 'Color','g')
% set(H(5), 'LineStyle','--','LineWidth',1,'MarkerSize',.1, 'Color','m')
xlabel('Debt/ Mean Income','FontSize',14,'FontWeight','bold', 'Interpreter','latex')
ylabel('Next-period Debt/ Mean Income','FontSize',14,'FontWeight','bold', 'Interpreter','latex')
leg1 = legend( '\, low $\: r$', '\, high $\:r$', '\, $\:45$ degree line');
set(leg1, 'Interpreter','latex')
set(leg1,'FontSize',14);
set(leg1,'Location','Northwest');
legend boxoff
axis([0.35 0.55 0.35 0.55])
yticks([.30 .35 .40 .45 .50 .55])
xticks([.30 .35 .40 .45 .50 .55])
% xticks([.32 .36 .40 .44 .48])
% print fig_JIE_1.eps -depsc
print fig_JIE_RR2_bnext_low_vol.eps -depsc



%This is figure A2-(b) in the Appendix:
i_y_plot = i_y_mean;
i_r_vol_plot =6;

weight = 1;
i_r_low=2;
vector_1 =(squeeze(-b_grid(b_next_matrix_plot(:, i_y_plot, i_r_low, i_r_vol_plot))/4) * weight + ...
    squeeze(-b_grid(b_next_matrix_plot(:, i_y_plot, i_r_low+1, i_r_vol_plot))/4) * (1-weight));

vector_1(vector_1==0)=nan;

i_r_high = 6;
vector_2 =(squeeze(-b_grid(b_next_matrix_plot(:, i_y_plot, i_r_high, i_r_vol_plot))/4) * weight + ...
    squeeze(-b_grid(b_next_matrix_plot(:, i_y_plot, i_r_high-1, i_r_vol_plot))/4) * (1-weight));

vector_2(vector_2==0)=nan;

figure
H = plot(-b_grid/4, [vector_1 vector_2 -b_grid/4]);
set(gca,'FontSize',14,'TickLabelInterpreter','latex')
set(H(1), 'LineStyle','--','LineWidth',3,'MarkerSize',.1, 'Color','r')
set(H(2), 'LineStyle','-','LineWidth',3,'MarkerSize',.1, 'Color','b')
set(H(3), 'LineStyle',':','LineWidth',1,'MarkerSize',.1, 'Color','k')
% set(H(4), 'LineStyle','-','LineWidth',1,'MarkerSize',.1, 'Color','g')
% set(H(5), 'LineStyle','--','LineWidth',1,'MarkerSize',.1, 'Color','m')
xlabel('Debt/ Mean Income','FontSize',14,'FontWeight','bold', 'Interpreter','latex')
ylabel('Next-period Debt/ Mean Income','FontSize',14,'FontWeight','bold', 'Interpreter','latex')
leg1 = legend( '\, low $\: r$', '\, high $\:r$', '\, $\:45$ degree line');
set(leg1, 'Interpreter','latex')
set(leg1,'FontSize',14);
set(leg1,'Location','Northwest');
legend boxoff
axis([0.35 0.55 0.35 0.55])
yticks([.30 .35 .40 .45 .50 .55])
xticks([.30 .35 .40 .45 .50 .55])
% xticks([.32 .36 .40 .44 .48])
% print fig_JIE_1.eps -depsc
print fig_JIE_RR2_bnext_high_vol.eps -depsc

pause

%% Spread plots

%construct the spread:

spread_matrix=zeros(b_num, y_num, r_num, r_vol_num);
spread_matrix_rt=zeros(b_num, y_num, r_num, r_vol_num);
spread_matrix_rw=zeros(b_num, y_num, r_num, r_vol_num);

for i_y=1:y_num
    for i_r = 1:r_num
        for i_r_vol =1:r_vol_num
            
            yield_rf(i_y, i_r, i_r_vol) = coupon_matrix(i_r,i_r_vol)/q_def_free_matrix(i_y,i_r,i_r_vol) - delta;
            
            for i_b=1:b_num
                yield_rf_new(i_b,i_y, i_r, i_r_vol) = coupon_matrix(i_r,i_r_vol)/q_def_free_new_matrix(i_b,i_y,i_r,i_r_vol) - delta;
                yield_long(i_b,i_y, i_r, i_r_vol) = coupon_matrix(i_r,i_r_vol)/q_matrix(i_b,i_y,i_r,i_r_vol) - delta;
                spread_matrix(i_b,i_y, i_r, i_r_vol)= 4*(yield_long(i_b,i_y, i_r, i_r_vol) - yield_rf_new(i_b, i_y, i_r, i_r_vol));
                b_choice_matrix(i_b,i_y, i_r, i_r_vol) = -b_grid(b_next_matrix_plot(i_b,i_y, i_r, i_r_vol))/4;
                
            end
        end
    end
end

b_choice_matrix(default_matrix==1)=nan;

% Next, we define the "spread_slope_matrix" (called just slope_matrix). It
% is quantifying the change in spreads when interest rate level moves from
% position 2 to 6, which at mean volatility it's roughly 100bps. The
% denominator is the change in the default-free yield for the same movement
% in the world interest rate.

slope_matrix = (spread_matrix(:,:,6,:) - spread_matrix(:,:,2,:))./...
    (4*(yield_rf_new(:,:,6,:) - yield_rf_new(:,:,2,:)));


% This is Figure 1-(a) in the paper:
figure
H = plot(y_grid, [slope_matrix(i_b_mean,:,2)' slope_matrix(i_b_mean,:,6)']);
set(gca,'FontSize',14,'TickLabelInterpreter','latex')
set(H(1), 'LineStyle','--','LineWidth',3,'MarkerSize',.1, 'Color','r')
set(H(2), 'LineStyle','-','LineWidth',3,'MarkerSize',.1, 'Color','b')
leg1 = legend('\, low $\: \sigma_r$', '\, high $\: \sigma_r$');
set(leg1,'Interpreter','latex','Location','NorthEast');
set(leg1,'FontSize',14);
xlabel('$\log (y)$','FontSize',14,'FontWeight','bold','interpreter','latex')
ylabel('$\Delta$ Spread / $\Delta r^f$','FontSize',14,'FontWeight','bold','interpreter','latex')
axis([-.14 .14 -.085 5])
legend boxoff
print fig_JIE_RR2_Delta_Spread_VOL.eps -depsc


% This is Figure 1-(b) in the paper:
figure
H = plot(y_grid, [slope_matrix(i_b_mean,:,4)' slope_matrix(i_b_mean-17,:,4)' slope_matrix(i_b_mean-36,:,4)']);
set(gca,'FontSize',14,'TickLabelInterpreter','latex')
set(H(1), 'LineStyle','--','LineWidth',3,'MarkerSize',.1, 'Color','r')
set(H(2), 'LineStyle','-','LineWidth',3,'MarkerSize',.1, 'Color','b')
set(H(3), 'LineStyle',':','LineWidth',3,'MarkerSize',.1, 'Color','k')
leg1 = legend('\, Mean debt (44\%)', '\, High debt (49\%)', '\, Very high debt (55\%)');
set(leg1,'Interpreter','latex','Location','NorthEast');
set(leg1,'FontSize',14);
xlabel('$\log (y)$','FontSize',14,'FontWeight','bold','interpreter','latex')
ylabel('$\Delta$ Spread / $\Delta r^f$','FontSize',14,'FontWeight','bold','interpreter','latex')
axis([-.14 .14 -.085 5])
legend boxoff
print fig_JIE_RR2_Delta_Spread_DEBT.eps -depsc

%% Debt Issuance plots

issuance_matrix = zeros(b_num,y_num,r_num, r_vol_num);

for ib = 1:b_num
    b_today = -b_grid(ib);
    
    for iy=1:y_num
        for ir = 1:r_num
            for ir_vol = 1:r_vol_num
                
                b_prime = -b_grid(b_next_matrix_plot(ib,iy,ir, ir_vol));
                issuance_matrix(ib,iy,ir, ir_vol) = 100*(b_prime - (1-delta) * b_today)/exp(y_grid(iy));
            end
        end
    end
    
end

issuance_matrix(default_matrix==1)=NaN; %Only look at issuance in No-Default states

%Similarly as above, we define the `issuance slope' matrix:
slope_matrix_issuance = (issuance_matrix(:,:,6,:) - issuance_matrix(:,:,2,:))./...
    (4*100*(yield_rf_new(:,:,6,:) - yield_rf_new(:,:,2,:)));

%This is figure 2-(a) in the paper:
figure
H = plot(-.25*b_grid, [issuance_matrix(:,i_y_mean,2,2) issuance_matrix(:,i_y_mean,6,2)]);
set(gca,'FontSize',14,'TickLabelInterpreter','latex')
set(H(1), 'LineStyle','--','LineWidth',3,'MarkerSize',.1, 'Color','r')
set(H(2), 'LineStyle','-','LineWidth',3,'MarkerSize',.1, 'Color','b')
leg1 = legend('\, low $r$', '\, high $r$');
set(leg1,'Interpreter','latex','Location','NorthEast');
set(leg1,'FontSize',14);
xlabel('Debt / Mean Income','FontSize',14,'FontWeight','bold','interpreter','latex')
ylabel('Issuance (as percent of Income)','FontSize',14,'FontWeight','bold','interpreter','latex')
axis([0 .5 0 25])
legend boxoff
print fig_JIE_RR2_Issuance_Policy_low_vol.eps -depsc

%This is figure 2-(b) in the paper:
figure
H = plot(-.25*b_grid, [issuance_matrix(:,i_y_mean,2,6) issuance_matrix(:,i_y_mean,6,6)]);
set(gca,'FontSize',14,'TickLabelInterpreter','latex')
set(H(1), 'LineStyle','--','LineWidth',3,'MarkerSize',.1, 'Color','r')
set(H(2), 'LineStyle','-','LineWidth',3,'MarkerSize',.1, 'Color','b')
leg1 = legend('\, low $r$', '\, high $r$');
set(leg1,'Interpreter','latex','Location','NorthEast');
set(leg1,'FontSize',14);
xlabel('Debt / Mean Income','FontSize',14,'FontWeight','bold','interpreter','latex')
ylabel('Issuance (as percent of Income)','FontSize',14,'FontWeight','bold','interpreter','latex')
axis([0 .5 0 25])
legend boxoff
print fig_JIE_RR2_Issuance_Policy_high_vol.eps -depsc

%% NEXT: load data from the basic-model econonmy
%
% ** NOTE** the data for the "basic" model (with a constant world interest
% rate) has to be first computed and then stored in a folder, whose name is
% of your choosing. Below, that name is RR2_basic. Be sure to change the
% lines below if you choose a different folder name.

load ../RR2_basic/graphs_b_grid_dss.txt
load ../RR2_basic/graphs_y_grid_dss.txt
load ../RR2_basic/graphs_r_grid_dss.txt
load ../RR2_basic/graphs_v_dss.txt
load ../RR2_basic/graphs_q_dss.txt
load ../RR2_basic/graphs_q_def_free.txt
load ../RR2_basic/graphs_default_dss.txt
load ../RR2_basic/graphs_b_next_dss.txt
load ../RR2_basic/graphs_dev_dss.txt
load ../RR2_basic/graphs_q_paid_dss.txt
load ../RR2_basic/graphs_r_vol_grid_dss.txt
load ../RR2_basic/graphs_trans_matrix_y.txt
load ../RR2_basic/graphs_consumption_dss.txt

b_grid_baseline = graphs_b_grid_dss;
y_grid_baseline = graphs_y_grid_dss;
r_grid_baseline = graphs_r_grid_dss;
r_vol_grid_baseline = graphs_r_vol_grid_dss;
v_baseline = graphs_v_dss;
q_baseline = graphs_q_dss;
q_def_free_baseline = graphs_q_def_free;
default_baseline = graphs_default_dss;
b_next_baseline = graphs_b_next_dss;
dev_baseline = graphs_dev_dss;
q_paid_baseline = graphs_q_paid_dss;
trans_matrix_y_baseline = graphs_trans_matrix_y;
consumption_baseline = graphs_consumption_dss;

b_num_baseline = length(b_grid_baseline);
y_num_baseline = length(y_grid_baseline);
r_num_baseline = length(r_grid_baseline)/length(r_vol_grid_baseline);
r_vol_num_baseline = length(r_vol_grid_baseline);

%%Create the matrices:
v0_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
v1_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
v_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
default_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
q_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
q_def_free_matrix_baseline = zeros( y_num_baseline, r_num_baseline, r_vol_num_baseline);
q_arellano_matrix_baseline = zeros(b_num_baseline, y_num_baseline);
v0_arellano_matrix_baseline = zeros(b_num_baseline, y_num_baseline);
v1_arellano_matrix_baseline = zeros(b_num_baseline, y_num_baseline);
v_arellano_matrix_baseline = zeros(b_num_baseline, y_num_baseline);
transition_matrix_y_baseline = zeros(y_num_baseline, y_num_baseline);
cons0_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
cons1_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
cons_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
b_next_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
b_next_arellano_matrix_baseline = zeros(b_num_baseline,y_num_baseline);
dev_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
q_paid_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);
tb_matrix_baseline = zeros(b_num_baseline, y_num_baseline, r_num_baseline, r_vol_num_baseline);

for i_vol = 1:r_vol_num_baseline
    for i_r = 1:r_num_baseline
        for i_y = 1:y_num_baseline
            
            q_def_free_matrix_baseline(i_y, i_r, i_vol) = q_def_free_baseline((i_vol-1)*r_num_baseline*y_num_baseline+ (i_r-1)*y_num_baseline+i_y);
            for i_b = 1:b_num_baseline
                
                v0_matrix_baseline(i_b, i_y, i_r, i_vol) = v_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b,2);
                v1_matrix_baseline(i_b, i_y, i_r, i_vol) = v_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b,3);
                v_matrix_baseline(i_b, i_y, i_r, i_vol) = v_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b,1);
                default_matrix_baseline(i_b, i_y, i_r, i_vol) = default_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b);
                q_matrix_baseline(i_b, i_y, i_r, i_vol) = q_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b);
                q_paid_matrix_baseline(i_b, i_y, i_r, i_vol) = q_paid_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b);
                b_next_matrix_baseline(i_b, i_y, i_r, i_vol) = b_next_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b);
                dev_matrix_baseline(i_b, i_y, i_r, i_vol) = dev_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b);
                cons0_matrix_baseline(i_b, i_y, i_r, i_vol) = consumption_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b,2);
                cons1_matrix_baseline(i_b, i_y, i_r, i_vol) = consumption_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b,3);
                cons_matrix_baseline(i_b, i_y, i_r, i_vol) = consumption_baseline((i_vol-1)*r_num_baseline*y_num_baseline*b_num_baseline+ (i_r-1)*y_num_baseline*b_num_baseline+(i_y-1)*b_num_baseline + i_b,1);
                
            end
        end
    end
end


spread_matrix_baseline=zeros(b_num, y_num, r_num_baseline, r_vol_num_baseline);
spread_matrix_rw_baseline=zeros(b_num, y_num, r_num_baseline, r_vol_num_baseline);

for i_y=1:y_num_baseline
    for i_r = 1:r_num_baseline
        for i_r_vol =1:r_vol_num_baseline
            
            yield_rf_baseline(i_y, i_r, i_r_vol) = coupon_matrix(i_r,i_r_vol)/q_def_free_matrix_baseline(i_y,i_r,i_r_vol) - delta;
            
            for i_b=1:b_num

                yield_long_baseline(i_b,i_y, i_r, i_r_vol) = coupon_matrix(i_r,i_r_vol)/q_matrix_baseline(i_b,i_y,i_r,i_r_vol) - delta;
                spread_matrix_baseline(i_b,i_y, i_r, i_r_vol)= 4*(yield_long_baseline(i_b,i_y, i_r, i_r_vol) - yield_rf_baseline(i_y, i_r, i_r_vol));
                
            end
        end
    end
end


for i=1:y_num_baseline
    for j=1:y_num_baseline
        transition_matrix_y_baseline(i, j) = trans_matrix_y_baseline((i-1)*y_num_baseline + j,1);
    end
end


% 1) Welfare gains/costs for initial debt = zero.


load graphs_pdf_y.txt
load graphs_pdf_r_vol.txt
load graphs_pdf_r.txt

pdf_y = graphs_pdf_y;
pdf_r_vol = graphs_pdf_r_vol;
pdf_r = graphs_pdf_r;

pdf_r_matrix = zeros(r_vol_num,r_num); %will have r across the columns, and r_vol as the different rows

for i_r_vol = 1:r_vol_num
    for i_r = 1:r_num
        pdf_r_matrix(i_r_vol, i_r)=pdf_r( (i_r_vol -1)*r_num + i_r);
    end
end

%1.a. For the full model
i_b_welfare=b_num; % the level of debt at which welfare gains are computed

for i_y =1:y_num
    
    acum_1=0;
    for i_r_vol = 1:r_vol_num
        acum_2=0;
        for i_r =1:r_num
            acum_2 = acum_2 + pdf_r_matrix(i_r_vol,i_r)* v_matrix(i_b_welfare,i_y,i_r,i_r_vol);
        end
        
        acum_1=acum_1 + acum_2 * pdf_r_vol(i_r_vol);
    end
    
    value_full(i_y) = acum_1;
end
value_full=value_full(:);

%1.b) for basic model
i_b_welfare_baseline=b_num_baseline; % the level of debt at which welfare gains are computed

value_baseline = v_matrix_baseline(i_b_welfare_baseline,:,1,1);
value_baseline = value_baseline(:); %make it column vector (in case it wasn't)
sigma_coeff = 2; %Coeff of RRA in the calibration

welfare_gain_full_to_base = 100*((value_baseline./value_full).^(1/(1-sigma_coeff))-1);


fprintf('Average welfare gains (in percent of consumption) \n')
fprintf('Full to Baseline           = %6.2f \n', 100*(((pdf_y' * value_baseline)/(pdf_y' * value_full))^(1/(1-sigma_coeff))-1))

welfare_gain_zero_debt = welfare_gain_full_to_base; %save this

% 2) Welfare gains/costs for initial debt = mean level observed in full
% simulation.


% 2.a) For full model
i_b_welfare=i_b_mean; % the level of debt at which welfare gains are computed


for i_y =1:y_num
    
    acum_1=0;
    for i_r_vol = 1:r_vol_num
        acum_2=0;
        for i_r =1:r_num
            acum_2 = acum_2 + pdf_r_matrix(i_r_vol,i_r)* v_matrix(i_b_welfare,i_y,i_r,i_r_vol);
        end
        
        acum_1=acum_1 + acum_2 * pdf_r_vol(i_r_vol);
    end
    
    value_full(i_y) = acum_1;
end

value_full=value_full(:);

nice_green = [0.4660, 0.6740, 0.1880];

%2.b) for basic model
i_b_welfare_baseline=i_b_mean; % the level of debt at which welfare gains are computed

value_baseline = v_matrix_baseline(i_b_welfare_baseline,:,1,1);
value_baseline = value_baseline(:); %make it column vector (in case it wasn't)

sigma_coeff = 2; %Coeff of RRA in the calibration

welfare_gain_mean_full_debt = 100*((value_baseline./value_full).^(1/(1-sigma_coeff))-1);

%This is figure 3 in the paper:
figure
H = plot(y_grid_baseline, [welfare_gain_zero_debt welfare_gain_mean_full_debt]);
set(gca,'FontSize',14,'TickLabelInterpreter','latex')
set(H(1), 'LineStyle','-','LineWidth',3,'MarkerSize',.1, 'Color',nice_green)
set(H(2), 'LineStyle','--','LineWidth',3,'MarkerSize',.1, 'Color','k')
xlabel('$\log(y)$','FontSize',14,'FontWeight','bold','interpreter','latex')
ylabel('Proportion of cons. (in percent)','FontSize',14,'FontWeight','bold','interpreter','latex')
leg1 = legend('\, Initial debt = 0', '\, Intial debt = avg. debt in full-model') ;
set(leg1,'Interpreter','latex','Location','NorthEast');
set(leg1,'FontSize',14);
legend boxoff
axis([-.2 .2 0 .03])
print fig_JIE_RR2_welfare.eps -depsc


fprintf('Full to Baseline (mean debt)           = %6.2f \n', 100*(((pdf_y' * value_baseline)/(pdf_y' * value_full))^(1/(1-sigma_coeff))-1))
