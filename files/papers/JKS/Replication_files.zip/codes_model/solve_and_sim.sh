#!/bin/bash
gfortran -O3 -o code_solve jks_long_dss.f90
./code_solve
matlab -nojvm -nodisplay -nosplash -r "run('moments_JKS_2022'); exit;"