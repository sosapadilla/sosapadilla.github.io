#0. Housekeeping ----

rm(list = ls())

# This function "pause" will stop the execution (exactly like 'pause' in Matlab or Fortran)

#Load packages
library(gplots)
library(openxlsx)
library(broom)
library(tidyverse)
library(mFilter)
library(corrplot)
library(zoo)

cat("\014") # clear the console
setwd("/Users/csosapad/Dropbox/JKS/JKS_editorial/data_files/")

# Load the dataset
load("JKS_dataset.Rdata")

# Construct table with the Targeted Moments ----
#
# Here we subset the data to match the country and time coverage in
# i) FoleyFisher-Guimaraes: 1998-2008. 
# ii) Arora-Cerisola: 1994-1999 (at the most)
# That implies we need use 1994-2008 for the time coverage.

list_FF <-c("BRAZIL","BULGARIA","MEXICO","PANAMA","PERU","VENEZUELA, RB")
list_AC <-c("ARGENTINA","BRAZIL","BULGARIA","MEXICO","PANAMA","COLOMBIA","POLAND","PHILIPPINES","THAILAND",
            "INDONESIA")

data_new <- data_moments%>%
  filter(Country %in% list_FF | Country %in% list_AC)

data_new <- data_new %>% 
  filter(!is.na(ca_y))%>%
  group_by(Country) %>% 
  mutate(hp_tb =hpfilter(ca_y, type = "lambda", freq = 6.25)$cycle) #Use 6.25 bc data is annual here.

moments_table_Papers <- data_new%>%
  filter(Year>=1994)%>%
  filter(Year <= 2008)%>%
  group_by(Country)%>%
  filter(crisis_dummy==0)%>%
  summarise(
    Debt = mean(td_y, na.rm = TRUE),
    Spread = mean(master_embi, na.rm=TRUE),
    SD.Spread = sd(master_embi, na.rm=TRUE),
    SD.Cons_SD.Y=sd(hp_lc,na.rm = TRUE)/sd(hp_ly,na.rm = TRUE),
    Corr.C.Y=cor(hp_ly,hp_lc, use="pairwise.complete.obs"),
    Correl.Spread.Y=cor(hp_ly,spread_gs, use="pairwise.complete.obs"),
  )
#The medians in the following "summary" are the source for our targeted moments:
summary(moments_table_Papers)


# SPREAD CORRELATION MATRIX (Using quarterly data) -----
# This section creates Figure A4 in the Appendix.

list_FF_new <-c("Brazil","Bulgaria","Mexico","Panama","Peru","Venezuela")
list_AC_new <-c("Argentina","Brazil","Bulgaria","Mexico","Panama","Colombia","Poland","Philippines","Thailand","Korea")
## Note: Indonesia is not in the Longstaff data

temp_cor <- df.longstaf %>%
  select(Country ,Year, EMBI.Spread, Trsy.Yield)

temp_cor <- temp_cor%>%
  mutate(Sov.yield = EMBI.Spread + Trsy.Yield*100)

temp_cor <- temp_cor %>%
  select(Country ,Year, Sov.yield)

temp_cor <- temp_cor%>%
  filter(Country %in% list_FF_new | Country %in% list_AC_new)

y_cor <- data_common_final%>%
  select(Country ,Year, log_gdp_pc_deviation_PPP)

y_cor <- y_cor%>%
  filter(Country %in% list_FF_new | Country %in% list_AC_new)


wide_y <-y_cor%>% 
  group_by(Country) %>% do(tibble::rowid_to_column(.)) %>% spread(Country, log_gdp_pc_deviation_PPP)

mywide_y <- subset(wide_y, select = -c(Year,rowid) )

#Now for the plot:
M_y <- cor(mywide_y,use="pairwise.complete.obs")
p.mat_y <- cor.mtest(mywide_y)$p

#order="alphabet"
#order = "hclust
Low_M_y <- M_y
Low_M_y[upper.tri(Low_M_y, diag = TRUE)] <- NA
view(Low_M_y)
mean(Low_M_y,na.rm = TRUE)
median(Low_M_y,na.rm = TRUE)

wide1 <-temp_cor%>% group_by(Country) %>% do(tibble::rowid_to_column(.)) %>% spread(Country, Sov.yield)
mywide <- subset(wide1, select = -c(Year,rowid) )

#Now for the plot:
M <- cor(mywide,use="pairwise.complete.obs")
p.mat <- cor.mtest(mywide)$p

Low_M <- M
Low_M[upper.tri(Low_M, diag = TRUE)] <- NA
#view(Low_M)
mean(Low_M,na.rm = TRUE) # This is the mean pairwise correlation reported in the paper.
median(Low_M,na.rm = TRUE)

setEPS()
postscript("fig_correlation_matrix.eps")
col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD", "#4477AA"))
corrplot(M, method = "color", col = col(200),
         type = "upper", order="hclust", number.cex = .5,
         addCoef.col = "black", # Add coefficient of correlation
         tl.col = "black", tl.srt = 90, # Text label color and rotation
         # Combine with significance
         p.mat = p.mat, sig.level = 0.05, insig = "pch",
         pch=NA_integer_,
         # hide correlation coefficient on the principal diagonal
         diag = FALSE)

dev.off()
