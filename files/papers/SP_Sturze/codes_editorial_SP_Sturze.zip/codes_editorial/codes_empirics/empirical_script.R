rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

######################################### Packages #########################################
library(corrplot)
library(RColorBrewer)
library(stargazer)
library(xlsx)
library(data.table)
library(car)
library(foreign)
library(AER)
library(plm)
library(gplots)
library(gmm)
library(haven)
library(purrr)
library(dplyr)
library(tables)
library(moments)
library(pastecs)
library(knitr)
library(plm)
library(mfx)
library(ggplot2)
library(texreg)
library(ggpubr)
library(margins)
library(sampleSelection)
library(openxlsx)
library(reshape2)
library(tidyverse)
library(ivpack)
library(robustbase)
library(sandwich)
library(lmtest)
library(modelr)
library(broom)
library(lubridate)
library(countrycode)
library(fuzzywuzzyR)
library(naniar)
library(devtools)
#install.packages("commarobust")
#devtools::install_github("acoppock/commarobust")
library(splines)
library(hablar)
library(xtable)

options(digits = 3)

######################################### Setup #########################################
#Dictionary (Country name)
Diccionario <- read.xlsx(xlsxFile = "Diccionario.Pais.xlsx")

robust_standard_errors = function(reg){
  coeftest(reg, vcov = vcovHC(reg, "HC1",method="arellano"))[,2]
  
}

#Ratings
ratings <- read.csv("ratings_scraper.csv", sep = ";")
colnames(ratings)[2] = "Country"
ratings <- ratings[,-3]
ratings$rating <- as.numeric(as.character(ratings$rating))
ratings$date <- as.Date(ratings$date)
ratings <- merge(x=ratings,y=Diccionario[,c("n","ratings.name")], by.x="Country", by.y = "ratings.name", all=TRUE) 

#Reserves
reserves <- read.csv("Reserves.csv")
colnames(reserves)[1]="Country"
colnames(reserves)[3]="date"
reserves$date <- as.Date(reserves$date, format="%d/%m/%Y")
reserves <- merge(x=reserves,y=Diccionario[,c("n","IMF.name")], by.x="Country", by.y = "IMF.name", all=TRUE) 
reserves <- reserves %>% drop_na(n)

#Risk Aversion
RA <- read.csv("RA.csv")
RA[RA == "."] <- NA
RA <- na.omit(RA)
#Months
RA$date <- as.Date(RA$DATE) 
colnames(RA)[2]="RiskA"
RA$RiskA <- as.numeric(as.character(RA$RiskA))
RA$meses <- months(RA$date)
RA$anio <- format(RA$date, format = "%Y")
RA <- RA %>%
 group_by(meses, anio) %>%
  summarise(RiskA=mean(RiskA))

#Spreads
spreads <- read.csv("svrg_spr.csv", header = FALSE, stringsAsFactors = FALSE)
spreads[spreads == ".."] <- NA
names(spreads) <- spreads[1,]
spreads <- spreads[-1,]
spreads <- spreads[,-3]
spreads <- spreads[,-1]
spreads <- melt(spreads, "Country", variable.name = "date", value.name = "spread")
spreads$date <- as.Date(spreads$date, format="%d/%m/%Y")
spreads$spread <- as.numeric(as.character(spreads$spread))
spreads <- merge(x=spreads,y=Diccionario[,c("n","spr.name")], by.x="Country", by.y = "spr.name", all=TRUE) 
spreads <- spreads %>% drop_na(n)

#Worldrate
WRate <- read.csv("WorldRate.csv")
WRate[WRate == "."] <- NA
WRate <- na.omit(WRate)
WRate$date <- as.Date(WRate$DATE)
WRate$DGS10 <- as.numeric(as.character(WRate$DGS10))
WRate$meses <- months(WRate$date)
WRate$anio <- format(WRate$date, format="%Y")
WRate <- WRate %>%
  group_by(meses, anio) %>%
  summarise(WRate=mean(DGS10))

#Debt Indicators
deuda <- read.csv("Debt.csv", header = FALSE)
names(deuda) <- deuda[1,]
deuda <- as.data.table(deuda, keep.rownames=TRUE)
deuda <- deuda[-1,]
deuda <- deuda[,-1]
colnames(deuda)[1]="Country"
colnames(deuda)[2]="Serie"
deuda <- melt(deuda, c("Country","Serie"), variable.name = "Year", value.name = "Valor")
deuda$Valor <- as.numeric(deuda$Valor) / 1000000
deuda <- dcast(deuda, value.var="Valor", formula = Country + Year ~ Serie, fun.aggregate = sum)
deuda <- merge(x=deuda,y=Diccionario[,c("n","WB.Name")], by.x="Country", by.y = "WB.Name", all=TRUE)
deuda <- deuda %>% drop_na(Country)

#GDP
GDP <- read.csv2("GDP_Monthly.csv", header = FALSE, stringsAsFactors = FALSE)
GDP <- data.frame(GDP)
names(GDP) <- as.factor(GDP[1,])
GDP <- GDP[-1,]
colnames(GDP)[3] = "GDP_USD"
GDP$GDP_USD <- gsub(",",".",x = GDP$GDP_USD)
GDP$GDP_USD <- as.numeric(as.character(GDP$GDP_USD))


#IFS
IFS <- read.csv("IFS.csv")
IFS <- IFS[,-2]
IFS$date <- as.Date(IFS$date)
IFS <- merge(x=IFS,y=Diccionario[,c("n","IMF.name")], by.x="Country", by.y = "IMF.name", all=TRUE)
IFS <- IFS %>% drop_na(Country)

#IFS#2
cboth <- read.csv2(file = "CB_other.csv",sep=",", stringsAsFactors = FALSE)
cboth$date <- as.Date(cboth$Time.Period)
cboth <- cboth[,-(2:3)]
colnames(cboth)[2:6]=c("Claims.onothers","MB","NetClaimsOnCGV","OtherItems","Shares.Equity")
#Transform to numbers
cboth <- cboth %>% 
  mutate_at(vars(Claims.onothers,MB,NetClaimsOnCGV,OtherItems,Shares.Equity), as.numeric)
#Dividing by one million
cboth[,(2:6)] <- cboth[,(2:6)]/ 1000000
cboth <- merge(x=cboth,y=Diccionario[,c("n","IMF.name")], by.x="Country.Name", by.y = "IMF.name", all=TRUE)
cboth <- cboth %>% drop_na(Country.Name)

#merge all
df <- merge(RA, WRate, by = c("meses","anio"), all=TRUE)
df2 <- merge(reserves, IFS, by= c("date", "n"), all=TRUE)
df2 <- df2[,-(3:4)]
df2 <- df2[,-4]
df2 <- merge(df2, spreads, by= c("date", "n"), all=TRUE)
df2 <- df2[,-18]
df2 <- merge(df2, ratings, by= c("date", "n"), all=TRUE)
df2 <- df2[,-19]
df2$meses <- months(df2$date)
df2$Year <- format(df2$date, format="%Y")
df2 <- merge(df2, deuda, by= c("Year", "n"), all=TRUE)
df2 <- df2[,-22]
df2 <- merge(x=df2, y=GDP, by.x=c("date","n"), by.y = c("date","n"), all=TRUE)
df2 <- merge(df2, df, by.x = c("Year", "meses"), by.y= c("anio","meses"), all=TRUE)
df2 <- merge(df2, cboth[,-1], by.x=c("date","n"), by.y = c("date","n"), all= TRUE)
df2<- data.frame(df2)
df2 <- merge(x=df2, y=Diccionario[,c("n","name")], by.x="n", by.y = "n", all=TRUE) 
#Save intermediate database
writexl::write_xlsx(df2,"df2.xlsx")


#Unified Dataset
base_ely <- df2 %>% drop_na(spread)
base_ely <- base_ely %>% replace_with_na(replace = list(spread = 0))
base_ely <- base_ely %>% drop_na(spread)
base_ely <- data.frame(base_ely)

#Dropping columns in dollars (only for countries such as USA, Ecuador, etc)
base_ely <- base_ely[,-9]
base_ely <- base_ely[,-10]
base_ely <- base_ely[,-11]
base_ely <- base_ely[,-12]
base_ely <- base_ely[,-13]
base_ely <- base_ely[,-14]

#Changing Names
colnames(base_ely)[6:7] = c("EReop","ERavg")
colnames(base_ely)[8:13] = c("DepAndSec","FDer","Loans","ClaimsNR","LiabNR","OthLiab")

#Variables like Levy Yeyati & Gomez (2019)
base_ely$Reserve_ratio <- as.numeric(as.character(base_ely$Reserves)) / as.numeric(as.character(base_ely$GDP_USD))
base_ely$Sovereign.Debt <- (as.numeric(as.character(base_ely$EDS_PrGPub)) +as.numeric(as.character(base_ely$EDS_PubG)))/ as.numeric(as.character(base_ely$GDP_USD))
base_ely$Private_Debt <- as.numeric(as.character(base_ely$EDS_PrNG)) / as.numeric(as.character(base_ely$GDP_USD))

#Risk Aversion in basis points
base_ely$RiskA <- (base_ely$RiskA) * 100

#As numeric, divided by one million
base_ely[,(8:13)] <- base_ely[,(8:13)] / 1000000

#dividing by exchange rate
base_ely[,(32:37)] <- base_ely[,(8:13)] / base_ely[,6]
base_ely[,(38:42)] <- base_ely[,(23:27)] / base_ely[,6]

#Changing Names
colnames(base_ely)[32:37] = c("DepAndSec_USD","FDer_USD","Loans_USD","ClaimsNR_USD","LiabNR_USD","OthLiab_USD")
colnames(base_ely)[38:42] = c("ClaimsOthers_USD","MB_USD","NConCGV_USD","OthItems_USD","Shares_USD")

#Construct the variables of interest! At Levels
base_ely$Remunerated_Liabilities<- base_ely$FDer_USD + base_ely$Loans_USD + base_ely$DepAndSec_USD +  base_ely$OthLiab_USD
base_ely$External_Liabilities <- base_ely$LiabNR_USD
base_ely$Reserve_ratio <- base_ely$ClaimsNR_USD

#Ratios
base_ely$Remunerated_Liabilities<- base_ely$Remunerated_Liabilities/base_ely$GDP_USD
base_ely$External_Liabilities <- base_ely$External_Liabilities/base_ely$GDP_USD
base_ely$Reserve_ratio <- base_ely$Reserve_ratio/base_ely$GDP_USD
base_ely$Money<- base_ely$MB_USD /base_ely$GDP_USD
base_ely$others_BS = + (base_ely$OthItems_USD + base_ely$Shares_USD - base_ely$NConCGV_USD - base_ely$ClaimsOthers_USD)/base_ely$GDP_USD

#in logs
base_ely$spread <- log(base_ely$spread)
base_ely$RiskA <- log(base_ely$RiskA)
base_ely$WRate <- log(base_ely$WRate)
base_ely$rating <- log(base_ely$rating)

#Exporting base
writexl::write_xlsx(base_ely,"base_ely.xlsx")
#Conserve an auxiliary
base_ely_aux <- base_ely

######################################### Table 3 #########################################
#view(base_ely)
mco0 <- lm(data = base_ely, formula = spread ~ RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt)
mco01<- plm(data = base_ely, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt, model = "within", effect = "individual", index = c("name", "date"))
mco02<- plm(data = base_ely, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS, model = "within", effect = "individual", index = c("name", "date"))
mco03<- plm(data = base_ely, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities, model = "within", effect = "individual", index = c("name", "date"))
mco04<- plm(data = base_ely, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS, model = "within", effect = "individual", index = c("name", "date"))
mco05<- plm(data = base_ely, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
mco06<- plm(data = base_ely, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
mco07<- plm(data = base_ely, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities +others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))


#Robust SE 
rse0 <- robust_standard_errors(mco0)
rse01 <- robust_standard_errors(mco01)
rse02 <- robust_standard_errors(mco02)
rse03 <- robust_standard_errors(mco03)
rse04 <- robust_standard_errors(mco04)
rse05 <- robust_standard_errors(mco05)
rse06 <- robust_standard_errors(mco06)
rse07 <- robust_standard_errors(mco07)


stargazer(mco0, mco01, mco02, mco03, mco04, mco05, mco06, mco07, 
          type = "text", align = TRUE, se=list(rse0, rse01,rse02, rse03, rse04, rse05, rse06, rse07), 
          column.separate = c(1,4,5), 
          #covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others  \\\\ Balance Sheet","External Liabilities"), 
          title = "Regresion results. Full Sample", omit="Year", 
          add.lines = list(c("Fixed effects?", "No", "Yes","Yes","Yes","Yes","Yes","Yes","Yes"),
                           c("Year dummies?","No","No","No","No","No","Yes","Yes","Yes")), 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))



######################################### Table 4 #########################################



b2 <- coef(mco02)[4]
b3 <- coef(mco03)[4]
se2 <- rse02[4]
se3 <- rse03[4]

z <- (b2-b3) / ((se2^2)+(se3^2))^(1/2)
pvalue <- 2*pnorm(-abs(z)) ;pvalue


b5 <- coef(mco03)[4]
b6 <- coef(mco04)[4]
se5 <- rse03[4]
se6 <- rse04[4]

z2 <- (b5-b6)/ ((se5^2)+(se6^2))^(1/2)
pvalue2 <- 2*pnorm(-abs(z2)) ;pvalue2

#Z

b4 <- coef(mco05)[4]
b7 <- coef(mco06)[4]
se4 <- rse05[4]
se7 <- rse06[4]

z3 <- (b4-b7)/ ((se4^2)+(se7^2))^(1/2)
pvalue3 <- 2*pnorm(-abs(z3)) ;pvalue3

b8 <- coef(mco07)[4]
se8 <- rse07[4]
z4 <- (b7-b8)/ ((se7^2)+(se8^2))^(1/2)
pvalue4 <- 2*pnorm(-abs(z4)) ;pvalue4



######################################### Table 5 By Splits (Here, Follow With Appendix C for the Whole Sample) #########################################

#Tables 5 and 6 are the results of all the following regressions and calculations.

######################################### Table C.1 ##############################

#Deficit
def <- read.xlsx("deficit_monthly.xlsx")
def$n <- as.character(def$n)
def$date <- as.Date(def$date)
def$Mdeficit <- as.numeric(def$Mdeficit  )  #*100
base <- merge(base_ely,def,by.x=c("n","date"),by.y=c("n","date"),all=F)

#Current Account
ca <- read.xlsx("ca to gdp_monthly.xlsx")
ca$n <- as.character(ca$n)
ca$date <- as.Date(ca$date)
ca$M.ca <- as.numeric(ca$M.ca) /100 
base <- merge(base,ca,by.x=c("n","date"),by.y=c("n","date"),all=F)

#Regressions
hi1<- plm(data = base, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + M.ca + Mdeficit, model = "within", effect = "individual", index = c("name", "date"))
hi2<- plm(data = base, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + M.ca + Mdeficit,model = "pooling",  index = c("name", "date"))
hi7<- plm(data = base, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS+ M.ca + Mdeficit, model = "within", effect = "individual", index = c("name", "date"))
hi8<- plm(data = base, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt +Money+others_BS+External_Liabilities+ M.ca + Mdeficit , model = "within", effect = "individual", index = c("name", "date"))
hi9<- plm(data = base, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS+ M.ca + Mdeficit , model = "within", effect = "individual", index = c("name", "date"))
hi7b<- plm(data = base, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS+ M.ca + Mdeficit + factor(Year) , model = "within", effect = "individual", index = c("name", "date"))
hi8b<- plm(data = base, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities+ M.ca + Mdeficit + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
hi9b<- plm(data = base, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS+ M.ca + Mdeficit + factor(Year), model = "within", effect = "individual", index = c("name", "date"))


#Robust SE
se1ca <- robust_standard_errors(hi1)
se2ca <- robust_standard_errors(hi2)
se7ca <- robust_standard_errors(hi7)
se8ca <- robust_standard_errors(hi8)
se9ca <- robust_standard_errors(hi9)
se7cab <- robust_standard_errors(hi7b)
se8cab <- robust_standard_errors(hi8b)
se9cab <- robust_standard_errors(hi9b)

#Output
stargazer(hi2,hi1,hi7b,hi8b,hi9b,hi7,hi8,hi9, 
          type = "text", align = TRUE, se=list(se2ca, se1ca,se7cab, se8cab, se9cab,se7ca, se8ca, se9ca), 
          column.separate = c(1,4,4), 
         covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities","Current \\\\ Account","Fiscal \\\\ Deficit"), 
          title = "Regresion results. Robustness Checks", omit="Year",
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))



######################################### Table C.2 #########################################

base<-base_ely
basedebt = base %>% filter(!is.na(Sovereign.Debt)) %>%
  mutate(quantile=ntile(Sovereign.Debt,3))


base_uno_obs = basedebt %>% filter(quantile == 1) #low debt
base_tres_obs = basedebt %>% filter(quantile == 3) #high debt


#Regressions
reg1_obs<- plm(data = base_uno_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+ Money+others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg2_obs<- plm(data = base_uno_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg3_obs<- plm(data = base_uno_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg7_obs<- plm(data = base_tres_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg8_obs<- plm(data = base_tres_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg9_obs<- plm(data = base_tres_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))


#Robust SE
rse1_obs = robust_standard_errors(reg1_obs)
rse2_obs = robust_standard_errors(reg2_obs)
rse3_obs = robust_standard_errors(reg3_obs)
rse7_obs = robust_standard_errors(reg7_obs)
rse8_obs = robust_standard_errors(reg8_obs)
rse9_obs = robust_standard_errors(reg9_obs)


#Output
stargazer(reg7_obs,reg8_obs,reg9_obs,reg1_obs,reg2_obs,reg3_obs, 
          type = "text", align = TRUE, se=list(rse7_obs,rse8_obs,rse9_obs,rse1_obs,rse2_obs,rse3_obs), 
          column.separate = c(1,4,4), 
          covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities"), 
          title = "Regression results. Split Sample by Debt", omit="Year", 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))


#Difference between coefficients  (RESULTS ON TABLE 6)

#High
b4 <- coef(reg7_obs)[4]
b7 <- coef(reg8_obs)[4]
se4 <- rse7_obs[4]
se7 <- rse8_obs[4]

z3 <- (b4-b7)/ ((se4^2)+(se7^2))^(1/2)
pvalue3 <- 2*pnorm(-abs(z3)) ;pvalue3


b8 <- coef(reg9_obs)[4]
se8 <- rse9_obs[4]

z4 <- (b7-b8)/ ((se7^2)+(se8^2))^(1/2)
pvalue4 <- 2*pnorm(-abs(z4)) ;pvalue4


#Low
b2 <- coef(reg1_obs)[4]
b3 <- coef(reg2_obs)[4]
se2 <- rse1_obs[4]
se3 <- rse2_obs[4]

z <- (b2-b3) / ((se2^2)+(se3^2))^(1/2)
pvalue <- 2*pnorm(-abs(z)) ;pvalue


b6 <- coef(reg3_obs)[4]
se6 <- rse3_obs[4]

z2 <- (b3-b6)/ ((se3^2)+(se6^2))^(1/2)
pvalue2 <- 2*pnorm(-abs(z2)) ;pvalue2




######################################### Table C.3 #########################################
basespread = base %>% group_by(n) %>% 
  summarise(spread=mean(spread)) %>% 
  mutate(mediana=median(spread),
         alto_spread=ifelse(spread>mediana,1,0),
         bajo_spread=ifelse(spread<=mediana,1,0))

base = merge(base,basespread[,c("n","alto_spread","bajo_spread")],by="n")

base$spread_alto = ifelse(base$bajo_spread==1,NA,base$spread)
base$spread_bajo = ifelse(base$alto_spread==1,NA,base$spread)


base_alto = base %>% filter(alto_spread==1)
base_bajo = base %>% filter(bajo_spread==1)

base = base %>% drop_na(WRate, rating, RiskA, Remunerated_Liabilities) %>% 
  filter(Remunerated_Liabilities!=0) %>% plm.data(index=c("n","date"))

#Regressions
psh<- plm(data = base_alto, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS+ factor(Year) , model = "within", effect = "individual", index = c("name", "date"))
psh2<- plm(data = base_alto, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
psh3<- plm(data = base_alto, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))
psh4<- plm(data = base_bajo, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS+ factor(Year) , model = "within", effect = "individual", index = c("name", "date"))
psh5<- plm(data = base_bajo, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
psh6<- plm(data = base_bajo, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))


#Robust Errors
se1 <- robust_standard_errors(psh)
se2 <- robust_standard_errors(psh2)
se3 <- robust_standard_errors(psh3)
se4 <- robust_standard_errors(psh4)
se5 <- robust_standard_errors(psh5)
se6 <- robust_standard_errors(psh6)

#Output
stargazer(psh,psh2,psh3,psh4,psh5,psh6, 
          type = "text", align = TRUE, se=list(se1,se2,se3,se4,se5,se6), 
          column.separate = c(1,4,4), 
          covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities","Current \\\\ Account","Fiscal \\\\ Deficit"), 
          title = "Regression results. Split Sample by Spreads", omit="Year", 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))

#Difference between coefficients  (RESULTS ON TABLE 6)

#High
b4 <- coef(psh)[4]
b7 <- coef(psh2)[4]
se.4 <- se1[4]
se.7 <- se2[4]

z3 <- (b4-b7)/ ((se.4^2)+(se.7^2))^(1/2)
pvalue3 <- 2*pnorm(-abs(z3)) ;pvalue3


b8 <- coef(psh3)[4]
se.8 <-se3[4]

z4 <- (b7-b8)/ ((se.7^2)+(se.8^2))^(1/2)
pvalue4 <- 2*pnorm(-abs(z4)) ;pvalue4


#Low
b2 <- coef(psh4)[4]
b3 <- coef(psh5)[4]
se.2 <- se4[4]
se.3 <- se5[4]

z <- (b2-b3) / ((se.2^2)+(se.3^2))^(1/2)
pvalue <- 2*pnorm(-abs(z)) ;pvalue


b6 <- coef(psh6)[4]
se.6 <- se6[4]

z2 <- (b3-b6)/ ((se.3^2)+(se.6^2))^(1/2)
pvalue2 <- 2*pnorm(-abs(z2)) ;pvalue2

######################################### Table C.4 ##############################
#Devaluation rate
deva <- base_ely %>%
  group_by(n, Year) %>%
  summarise(ERanual = mean(EReop))
#We compute the devaluation for year in Excel and then come back to make the average devaluation rate

deva <- read.xlsx(xlsxFile = "deva.xlsx")

deva <- deva %>%
  group_by(n) %>%
  summarise(devaprom = mean(Deval))

basedeva <- merge(base_ely,deva, by="n", all=TRUE)
basedeva$HighRate <- ifelse(basedeva$devaprom >=0.05, 1, 0)

#Subset
HD <- basedeva %>% filter(HighRate==1)
LD <- basedeva %>% filter(HighRate==0)

#Regressions
hd1<- plm(data = HD, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
hd2<- plm(data = HD, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
hd3<- plm(data = HD, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
ld1<- plm(data = LD, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
ld2<- plm(data = LD, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
ld3<- plm(data = LD, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))



#Robust SE
dd1 <- robust_standard_errors(hd1)
dd2 <- robust_standard_errors(hd2)
dd3 <- robust_standard_errors(hd3)
dd4 <- robust_standard_errors(ld1)
dd5 <- robust_standard_errors(ld2)
dd6 <- robust_standard_errors(ld3)

#Output
stargazer(hd1, hd2, hd3, ld1, ld2, ld3, 
          type = "text", align = TRUE, se=list(dd1, dd2,dd3, dd4, dd5, dd6), 
          column.separate = c(1,4,4), 
          covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities","Current \\\\ Account","Fiscal \\\\ Deficit"), 
          title = "Regression results. Split Sample by Rate of Devaluation", omit="Year", 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))

#Difference between coefficients  (RESULTS ON TABLE 6)

#High
b4 <- coef(hd1)[4]
b7 <- coef(hd2)[4]
se.4 <- dd1[4]
se.7 <- dd2[4]

z3 <- (b4-b7)/ ((se.4^2)+(se.7^2))^(1/2)
pvalue3 <- 2*pnorm(-abs(z3)) ;pvalue3


b8 <- coef(hd3)[4]
se.8 <-dd3[4]

z4 <- (b7-b8)/ ((se.7^2)+(se.8^2))^(1/2)
pvalue4 <- 2*pnorm(-abs(z4)) ;pvalue4


#Low
b2 <- coef(ld1)[4]
b3 <- coef(ld2)[4]
se.2 <- dd4[4]
se.3 <- dd5[4]

z <- (b2-b3) / ((se.2^2)+(se.3^2))^(1/2)
pvalue <- 2*pnorm(-abs(z)) ;pvalue


b6 <- coef(ld3)[4]
se.6 <- dd6[4]

z2 <- (b3-b6)/ ((se.3^2)+(se.6^2))^(1/2)
pvalue2 <- 2*pnorm(-abs(z2)) ;pvalue2

######################################### Table C.5 ##############################
def <- read.csv(file = "def_fisc.csv")
def <- def[,-(5:6)]
def <- def[,-2]
colnames(def) <- c("Country","Year","def_fisc")
def$def_fisc <- as.numeric(as.character(def$def_fisc))/100
def <- merge(def,y=Diccionario[,c("n","IMF.name")], by.x="Country", by.y = "IMF.name", all=TRUE)
def <- def %>% drop_na(n)  
def <- def %>% drop_na(def_fisc)

basedeficit <- merge(x=base_ely,y=def[,c("n","Year","def_fisc")],by=c("n","Year"), all=TRUE)
basedeficit <- basedeficit %>% drop_na(spread)


#Consolidated Dataset
def <- basedeficit %>% 
  group_by(n, Year) %>%
  summarise(FBProm = mean(def_fisc))

def <- def %>% 
  group_by(n) %>%
  summarise(FBProm = mean(FBProm))

basedeficit <- merge(base_ely,def, by="n", all=TRUE)
basedeficit$deficitario <- ifelse(basedeficit$FBProm <0, 1, 0)
basedeficit <- basedeficit %>% drop_na(FBProm)

DF <- basedeficit %>% filter(deficitario==1)
SF <- basedeficit %>% filter(deficitario==0)


#Regressions
df1<- plm(data = DF, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
df2<- plm(data = DF, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
df3<- plm(data = DF, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
sf1<- plm(data = SF, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
sf2<- plm(data = SF, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
sf3<- plm(data = SF, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))



#Robust SE 
rd1 <- robust_standard_errors(df1)
rd2 <- robust_standard_errors(df2)
rd3 <- robust_standard_errors(df3)
rd4 <- robust_standard_errors(sf1)
rd5 <- robust_standard_errors(sf2)
rd6 <- robust_standard_errors(sf3)

#Output
stargazer(df1, df2, df3, sf1, sf2, sf3, 
          type = "text", align = TRUE, se=list(rd1, rd2,rd3, rd4, rd5, rd6), 
          column.separate = c(1,4,4), 
          covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities","Current \\\\ Account","Fiscal \\\\ Deficit"), 
          title = "Regression results. Split Sample by Deficit", omit="Year", 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))


#Difference between coefficients (RESULTS ON TABLE 6)

#With
b4 <- coef(df1)[4]
b7 <- coef(df2)[4]
se.4 <- rd1[4]
se.7 <- rd2[4]

z3 <- (b4-b7)/ ((se.4^2)+(se.7^2))^(1/2)
pvalue3 <- 2*pnorm(-abs(z3)) ;pvalue3


b8 <- coef(df3)[4]
se.8 <-rd3[4]

z4 <- (b7-b8)/ ((se.7^2)+(se.8^2))^(1/2)
pvalue4 <- 2*pnorm(-abs(z4)) ;pvalue4


#Without
b2 <- coef(sf1)[4]
b3 <- coef(sf2)[4]
se.2 <- rd4[4]
se.3 <- rd5[4]

z <- (b2-b3) / ((se.2^2)+(se.3^2))^(1/2)
pvalue <- 2*pnorm(-abs(z)) ;pvalue


b6 <- coef(sf3)[4]
se.6 <- rd6[4]

z2 <- (b3-b6)/ ((se.3^2)+(se.6^2))^(1/2)
pvalue2 <- 2*pnorm(-abs(z2)) ;pvalue2

######################################### Table C.6 ##############################
#Dollar
dollar <- read.csv("dollar.csv",header = FALSE, stringsAsFactors = FALSE)
dollar <- dollar[-(1:2),]
names(dollar) <- dollar[1,]
dollar <- dollar[-1,]
dollar <- merge(x=dollar,y=Diccionario[,c("n","WB.Name")], by.x="country", by.y = "WB.Name", all=TRUE) 
dollar$dollar <- as.numeric(dollar$dollar)
dollar <- dollar %>% drop_na(dollar)

dollar <- dollar %>%
  group_by(n) %>%
  summarise(dollar_prom = mean(dollar))

basedolar <- merge(base_ely,dollar, by="n", all=TRUE)
basedolar$dolarizado <- ifelse(basedolar$dollar_prom >0.2, 1, 0)
basedolar <- basedolar %>% drop_na(spread)
basedolar <- basedolar %>% drop_na(dollar_prom)
dolarsi <- basedolar %>% filter(dolarizado==1)
dolarno <- basedolar %>% filter(dolarizado==0)

#Regressions
dol1<- plm(data = dolarsi, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
dol2<- plm(data = dolarsi, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
dol3<- plm(data = dolarsi, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities +others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))
ndol1<- plm(data = dolarno, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
ndol2<- plm(data = dolarno, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
ndol3<- plm(data = dolarno, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))



#Robust SE 
error.dol1 <- robust_standard_errors(dol1)
error.dol2 <- robust_standard_errors(dol2)
error.dol3 <- robust_standard_errors(dol3)
error.ndol1 <- robust_standard_errors(ndol1)
error.ndol2 <- robust_standard_errors(ndol2)
error.ndol3 <- robust_standard_errors(ndol3)


#Output
stargazer(dol1,dol2,dol3,ndol1,ndol2,ndol3, 
          type = "text", align = TRUE, se=list(error.dol1,error.dol2,error.dol3,error.ndol1,error.ndol2,error.ndol3), 
          column.separate = c(1,4,4), 
          covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities","Current \\\\ Account","Fiscal \\\\ Deficit"), 
          title = "Regression results. Split Sample by Dollarizated Countries", omit="Year", 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))

#Difference between coefficients   (RESULTS ON TABLE 6)

#Dollarizated
b4 <- coef(dol1)[4]
b7 <- coef(dol2)[4]
se.4 <- error.dol1[4]
se.7 <- error.dol2[4]

z3 <- (b4-b7)/ ((se.4^2)+(se.7^2))^(1/2)
pvalue3 <- 2*pnorm(-abs(z3)) ;pvalue3


b8 <- coef(dol3)[4]
se.8 <-error.dol3[4]

z4 <- (b7-b8)/ ((se.7^2)+(se.8^2))^(1/2)
pvalue4 <- 2*pnorm(-abs(z4)) ;pvalue4


#Non-Dollarizated
b2 <- coef(ndol1)[4]
b3 <- coef(ndol2)[4]
se.2 <- error.ndol1[4]
se.3 <- error.ndol2[4]

z <- (b2-b3) / ((se.2^2)+(se.3^2))^(1/2)
pvalue <- 2*pnorm(-abs(z)) ;pvalue


b6 <- coef(ndol3)[4]
se.6 <- error.ndol3[4]

z2 <- (b3-b6)/ ((se.3^2)+(se.6^2))^(1/2)
pvalue2 <- 2*pnorm(-abs(z2)) ;pvalue2



######################################### Table C.7 ##############################
base<-base_ely
basedebt2 = base %>% filter(!is.na(Sovereign.Debt)) %>%
  group_by(n) %>%
  summarise(Sovereign.Debt=mean(Sovereign.Debt)) %>%
  mutate(quantile=ntile(Sovereign.Debt,3))

basedebt2.2 = merge(base,basedebt2[,c("n","quantile")],by="n")


base_uno_obs = basedebt2.2 %>% filter(quantile == 1) #low debt
base_tres_obs = basedebt2.2 %>% filter(quantile == 3) #high debt


#Regressions
reg1_obs<- plm(data = base_uno_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+ Money+others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg2_obs<- plm(data = base_uno_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg3_obs<- plm(data = base_uno_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg7_obs<- plm(data = base_tres_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg8_obs<- plm(data = base_tres_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
reg9_obs<- plm(data = base_tres_obs, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))


#Robust SE
rse1_obs = robust_standard_errors(reg1_obs)
rse2_obs = robust_standard_errors(reg2_obs)
rse3_obs = robust_standard_errors(reg3_obs)
rse7_obs = robust_standard_errors(reg7_obs)
rse8_obs = robust_standard_errors(reg8_obs)
rse9_obs = robust_standard_errors(reg9_obs)


#Output
stargazer(reg7_obs,reg8_obs,reg9_obs,reg1_obs,reg2_obs,reg3_obs, 
          type = "text", align = TRUE, se=list(rse7_obs,rse8_obs,rse9_obs,rse1_obs,rse2_obs,rse3_obs), 
          column.separate = c(1,4,4), 
          covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities"), 
          title = "Regression results. Split Sample by Country Debt", omit="Year", 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))



######################################### Table C.8 ##############################
#Monetary Policy Interest Rate (IFS)
t_int <- read.csv("tasa_int.csv")
t_int$date <- as.Date(t_int$date, format="%d/%m/%Y")
t_int$Financial <- as.numeric(as.character(t_int$Financial))
t_int <- merge(x=t_int,y=Diccionario[,c("n","IMF.name")], by.x="Country", by.y = "IMF.name", all=TRUE)
t_int <- t_int %>% drop_na(Country)
t_int <- t_int %>% drop_na(Financial)
t_int <- t_int %>% drop_na(n)

baseint <- merge(x=base_ely, y=t_int[,c("n","Financial","date")], by.x=c("n", "date"), by.y=c("n","date"),all=TRUE)
baseint <- baseint %>% drop_na(spread)
base.split <- baseint %>% drop_na(Financial)

average <- base.split %>%
  group_by(n) %>%
  summarise(avg = mean(Financial))

base.split <- merge(base.split, average, by="n", all=TRUE)
base.split$HighRate <- ifelse(base.split$avg >=7.99, 1, 0)

HR <- base.split %>% filter(HighRate==1)
LR <- base.split %>% filter(HighRate==0)

#Regressions
h1<- plm(data = HR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
h2<- plm(data = HR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
h3<- plm(data = HR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
l1<- plm(data = LR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
l2<- plm(data = LR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
l3<- plm(data = LR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))


#Robust SE
bb1 <- robust_standard_errors(h1)
bb2 <- robust_standard_errors(h2)
bb3 <- robust_standard_errors(h3)
bb4 <- robust_standard_errors(l1)
bb5 <- robust_standard_errors(l2)
bb6 <- robust_standard_errors(l3)


#Mean of Inflation Rate (IFS)
infl <- read.csv("inflacion_IFS.csv", stringsAsFactors = FALSE)
infl <- infl[,-2]
infl <- infl[,-(4:6)]
colnames(infl)[1:3]=c("Country","date","infl")
infl$date <- as.Date(infl$date, format="%Y")
infl$infl <- as.numeric(as.character(infl$infl))
infl[,1][infl[,1]=="Afghanistan, Islamic Rep. of"] = "Afghanistan, Islamic Republic of"

infl <- merge(x=infl,y=Diccionario[,c("n","IMF.name")], by.x="Country", by.y = "IMF.name", all=TRUE)
infl <- infl %>% drop_na(Country)
infl <- infl %>% drop_na(infl)
infl <- infl %>% drop_na(n)

average2 <- infl %>%
  group_by(n) %>%
  summarise(avg = mean(infl))

base.infl <- merge(base_ely, average2, by="n", all=TRUE)
base.infl <- base.infl %>% drop_na(spread)
base.infl$HighRate <- ifelse(base.infl$avg >=10, 1, 0)

HIR <- base.infl %>% filter(HighRate==1)
LIR <- base.infl %>% filter(HighRate==0)

#Regressions
hi1<- plm(data = HIR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
hi2<- plm(data = HIR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
hi3<- plm(data = HIR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
li1<- plm(data = LIR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
li2<- plm(data = LIR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
li3<- plm(data = LIR, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))


#Robust SE 
ii1 <- robust_standard_errors(hi1)
ii2 <- robust_standard_errors(hi2)
ii3 <- robust_standard_errors(hi3)
ii4 <- robust_standard_errors(li1)
ii5 <- robust_standard_errors(li2)
ii6 <- robust_standard_errors(li3)

#Output
stargazer(h1, h2, h3, l1, l2, l3, hi1, hi2, hi3, li1,li2,li3, 
          type = "text", align = TRUE, se=list(bb1, bb2,bb3, bb4, bb5, bb6, ii1,ii2,ii3,ii4,ii5,ii6), 
          column.separate = c(3,3,3), 
          column.labels = c("High interest Rate","Low interest Rate","High Inflation Rate","Low inflation Rate"),
          covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities","Current \\\\ Account","Fiscal \\\\ Deficit"), 
          title = "Regression results by Interest Rate and Inflation Rate", omit="Year", 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))


######################################### Table C.9 ##############################
# Full Samples

#Dollar
totd1<- plm(data = basedolar, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
totd2<- plm(data = basedolar, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
totd3<- plm(data = basedolar, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))

error.totd1 <- robust_standard_errors(totd1)
error.totd2 <- robust_standard_errors(totd2)
error.totd3 <- robust_standard_errors(totd3)

#Deficit 

fb1<- plm(data = basedeficit, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
fb2<- plm(data = basedeficit, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
fb3<- plm(data = basedeficit, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))

error.fb1 <- robust_standard_errors(fb1)
error.fb2 <- robust_standard_errors(fb2)
error.fb3 <- robust_standard_errors(fb3)


#Output
stargazer(totd1, totd2, totd3, fb1, fb2, fb3, 
          type = "text", align = TRUE, se=list(error.totd1, error.totd2, error.totd3, error.fb1, error.fb2, error.fb3), 
          column.separate = c(3,3), 
          column.labels = c("Dollar sample","Deficit sample"),
          covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others \\\\ Balance Sheet","External Liabilities","Current \\\\ Account","Fiscal \\\\ Deficit"), 
          title = "Results for Fiscal Balance and Dollarization Samples", omit="Year", 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))




######################################### Exogenous Shocks (Table 7 and C.10) ######################################### 

#Dataset VIX
pp <- readxl::read_xlsx("pseudo_panel.xlsx",sheet = "Sheet1")

#Setup Variables
pp$Date <- as.Date(pp$Date)
pp$R_to_EL <- as.numeric(pp$R_to_EL) #to filter
pp$R_to_RL <- as.numeric(pp$R_to_RL) #to filter


#Variables of Interest  (Liabilities to Reserves)
pp$EL_to_R <- as.numeric(pp$EL_to_R)
pp$RL_to_R <- as.numeric(pp$RL_to_R)



#---------------------------Regression for Pooled (for Table 7)------------------------------#


### All observations
#Domestic Liabilities
pp2.inv<- filter(pp, !is.na(var_abs) & !is.na(R_to_RL) & R_to_RL!="Inf" & var_abs>=0) 

regpp2inv<-plm(data = pp2.inv, formula = var_abs ~  RL_to_R,model = "pooling",
               index = c("Pais", "Date"))

se.regpp2inv<- robust_standard_errors(regpp2inv)


#External Liabilities
pp3.inv<- filter(pp, !is.na(var_abs) & !is.na(R_to_EL) & var_abs>=0)

regpp3inv<-plm(data = pp3.inv, formula = var_abs ~  EL_to_R,model = "pooling",
               index = c("Pais", "Date"))

se.regpp3inv<- robust_standard_errors(regpp3inv)


stargazer(regpp2inv,regpp3inv, type = "text", se=list(se.regpp2inv, se.regpp3inv),
          covariate.labels = c("Domestic \\\\ Liabilities", "External \\\\ Liabilities"),
          title = "Regression Results. Pooled of Exogenous Shocks",
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))

#Difference Between Coefficients
b4 <- coef(regpp3inv)[2]
b7 <- coef(regpp2inv)[2]
se.4 <- se.regpp3inv[2]
se.7 <- se.regpp2inv[2]

z3 <- (b4-b7)/ ((se.4^2)+(se.7^2))^(1/2)
pvalue3 <- 2*pnorm(-abs(z3)) ;pvalue3         


#-----------------Regression for Pooled without outlier (For table C.10)-----------------------#
#Domestic Liabilities
pp2.inv<- filter(pp, !is.na(var_abs) & !is.na(R_to_RL) & R_to_RL!="Inf" & var_abs>=0 &var_abs<460)

regpp2inv<-plm(data = pp2.inv, formula = var_abs ~  RL_to_R,model = "pooling",
               index = c("Pais", "Date"))

se.regpp2inv<- robust_standard_errors(regpp2inv)


#External Liabilities
pp3.inv<- filter(pp, !is.na(var_abs) & !is.na(R_to_EL) & var_abs>=0&var_abs<460)

regpp3inv<-plm(data = pp3.inv, formula = var_abs ~  EL_to_R,model = "pooling",
               index = c("Pais", "Date"))

se.regpp3inv<- robust_standard_errors(regpp3inv)


stargazer(regpp2inv,regpp3inv, type = "text", se=list(se.regpp2inv, se.regpp3inv),
          covariate.labels = c("Domestic \\\\ Liabilities", "External \\\\ Liabilities"),
          title = "Regression Results. Pooled of Exogenous Shocks without Outlier",
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))


#Difference Between Coefficients
b4 <- coef(regpp3inv)[2]
b7 <- coef(regpp2inv)[2]
se.4 <- se.regpp3inv[2]
se.7 <- se.regpp2inv[2]

z3 <- (b4-b7)/ ((se.4^2)+(se.7^2))^(1/2)
pvalue3 <- 2*pnorm(-abs(z3)) ;pvalue3   







#------------------------Regressions for Events (For table 7)------------------------------#


#Vector of events and pvalues
z<- c("2010-05-07","2011-08-08","2015-08-24")
pv<-c()
### All observations
for (i in z) {
  #Domestic Liabilities
  pp2<- filter(pp, !is.na(var_abs) & !is.na(R_to_RL) & R_to_RL!="Inf" & Date==i & var_abs >=0)
  
  regpp2<-lm(data = pp2, formula = var_abs ~  RL_to_R)
  se.regpp2<- robust_standard_errors(regpp2)
  
  #External Liabilities
  pp3<- filter(pp, !is.na(var_abs) & !is.na(R_to_EL) & Date==i & var_abs >=0)
  
  regpp3<-lm(data = pp3, formula = var_abs ~  EL_to_R)
  se.regpp3<- robust_standard_errors(regpp3)
  
 
  stargazer(regpp2,regpp3, type = "text",se=list(se.regpp2, se.regpp3),
            covariate.labels = c("Domestic \\\\ Liabilities", "External \\\\ Liabilities"),
            title = paste("Regression Results. Event",i),
            model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))
  
#  Difference Between Coefficients
  b4 <- coef(regpp3)[2]
  b7 <- coef(regpp2)[2]
  se.4 <- se.regpp3[2]
  se.7 <- se.regpp2[2]

  z3 <- (b4-b7)/ ((se.4^2)+(se.7^2))^(1/2)
  pv[i] <- round(2*pnorm(-abs(z3)),3)

}

#Vector of p-values differences between coefficients
pv


#------------------------Regressions for Events Without Outlier (For table C.10)------------------------------#

pvo<-c() #Vector for p-values without outlier
for (i in z) {
  #Domestic Liabilities
  pp2<- filter(pp, !is.na(var_abs) & !is.na(R_to_RL) & R_to_RL!="Inf" & Date==i & var_abs >=0 & var_abs < 465)
  
  regpp2<-lm(data = pp2, formula = var_abs ~  RL_to_R)
  se.regpp2<- robust_standard_errors(regpp2)
  
  #External Liabilities
  pp3<- filter(pp, !is.na(var_abs) & !is.na(R_to_EL) & Date==i & var_abs >=0 & var_abs < 465)
  
  regpp3<-lm(data = pp3, formula = var_abs ~  EL_to_R)
  se.regpp3<- robust_standard_errors(regpp3)
  
  stargazer(regpp2,regpp3, type = "text",se=list(se.regpp2, se.regpp3),
            covariate.labels = c("Domestic \\\\ Liabilities", "External \\\\ Liabilities"),
            title = paste("Regression Results. Event",i, " Without Outlier"),
            model.names = FALSE, digits = 2,column.sep.width = "-25pt", omit.stat = c("f","ser"))
  
  #  Difference Between Coefficients
  b4 <- coef(regpp3)[2]
  b7 <- coef(regpp2)[2]
  se.4 <- se.regpp3[2]
  se.7 <- se.regpp2[2]
  
  z3 <- (b4-b7)/ ((se.4^2)+(se.7^2))^(1/2)
  pvo[i] <- round(2*pnorm(-abs(z3)),3)
}

#Vector of p-values differences between coefficients
pvo




######################################### Table 8: Adding the currency composition of private debt #######

#Load the data
priv_debt_currency_comp <- read.csv("Private_debt_currency_composition.csv")
priv_debt_currency_comp <- priv_debt_currency_comp %>% 
  mutate(date=as.Date(date)) %>% 
  mutate(n=as.character(n))
#Join the dataset
data_table_8 <- base_ely_aux %>% 
  left_join(.,priv_debt_currency_comp,by=c("date","n"))

#Regressions
mco0_t8 <- lm(data = data_table_8, formula = spread ~ RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt)
mco01_t8<- plm(data = data_table_8, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt, model = "within", effect = "individual", index = c("name", "date"))
mco02_t8<- plm(data = data_table_8, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS+foreign_ratio, model = "within", effect = "individual", index = c("name", "date"))
mco03_t8<- plm(data = data_table_8, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities+foreign_ratio, model = "within", effect = "individual", index = c("name", "date"))
mco04_t8<- plm(data = data_table_8, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS+foreign_ratio, model = "within", effect = "individual", index = c("name", "date"))
mco05_t8<- plm(data = data_table_8, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS+foreign_ratio+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))
mco06_t8<- plm(data = data_table_8, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities+foreign_ratio + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
mco07_t8<- plm(data = data_table_8, formula = spread ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities +others_BS+foreign_ratio+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))

#Robust SE 
rse0_t8 <- robust_standard_errors(mco0_t8)
rse01_t8 <- robust_standard_errors(mco01_t8)
rse02_t8 <- robust_standard_errors(mco02_t8)
rse03_t8 <- robust_standard_errors(mco03_t8)
rse04_t8 <- robust_standard_errors(mco04_t8)
rse05_t8 <- robust_standard_errors(mco05_t8)
rse06_t8 <- robust_standard_errors(mco06_t8)
rse07_t8 <- robust_standard_errors(mco07_t8)



stargazer(mco0_t8, mco01_t8, mco02_t8, mco03_t8, mco04_t8, mco05_t8, mco06_t8, mco07_t8, 
          type = "text", align = TRUE, se=list(rse0_t8, rse01_t8,rse02_t8, rse03_t8, rse04_t8, rse05_t8, rse06_t8, rse07_t8), 
          #    p=list(p1,p1,p2,p3,p4,p5,p6,p7),
          column.separate = c(1,4,4), 
          title = "Regresion results. Full Sample", omit="Year", 
          keep=c("Reserve_ratio","foreign_ratio"),
          covariate.labels = c("Reserve Ratio","Priv. Debt currency comp."), 
          add.lines = list(c("Fixed effects?", "No", "Yes","Yes","Yes","Yes","Yes","Yes","Yes"),
                           c("Year dummies?","No","No","No","No","No","Yes","Yes","Yes")), 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))


######################################### Table C.11: Adding the currency composition of private debt #######


stargazer(mco0_t8, mco01_t8, mco02_t8, mco03_t8, mco04_t8, mco05_t8, mco06_t8, mco07_t8, 
          type = "text", align = TRUE, se=list(rse0_t8, rse01_t8,rse02_t8, rse03_t8, rse04_t8, rse05_t8, rse06_t8, rse07_t8), 
          #    p=list(p1,p1,p2,p3,p4,p5,p6,p7),
          column.separate = c(1,4,4), 
          title = "Regresion results. Full Sample", omit="Year", 
          #keep=c("Reserve_ratio","Private_Debt","domestic_ratio"),
          #covariate.labels = c("Reserve Ratio","Private Debt","Priv. Debt currency comp."), 
          add.lines = list(c("Fixed effects?", "No", "Yes","Yes","Yes","Yes","Yes","Yes","Yes"),
                           c("Year dummies?","No","No","No","No","No","Yes","Yes","Yes")), 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))


######################################### Table 9: The effect on Financial Conditions #######


#Import the database
Financial_conditions <- read.csv("Financial_Conditions.csv")
#Mutate to dates
Financial_conditions <- Financial_conditions %>%
  mutate(date=as.Date(date)) %>% 
  mutate(n=as.character(n))

#Join the dataset
data_table_9 <- base_ely_aux %>% 
    left_join(.,Financial_conditions,by=c("date","n"))
  
mco0_t9 <- lm(data = data_table_9, formula = Financial_Conditions ~ RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt)
mco01_t9<- plm(data = data_table_9, formula = Financial_Conditions ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt, model = "within", effect = "individual", index = c("name", "date"))
mco02_t9<- plm(data = data_table_9, formula = Financial_Conditions ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS, model = "within", effect = "individual", index = c("name", "date"))
mco03_t9<- plm(data = data_table_9, formula = Financial_Conditions ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities, model = "within", effect = "individual", index = c("name", "date"))
mco04_t9<- plm(data = data_table_9, formula = Financial_Conditions ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities+others_BS, model = "within", effect = "individual", index = c("name", "date"))
mco05_t9<- plm(data = data_table_9, formula = Financial_Conditions ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+Money+others_BS + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
mco06_t9<- plm(data = data_table_9, formula = Financial_Conditions ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Money+others_BS+External_Liabilities + factor(Year), model = "within", effect = "individual", index = c("name", "date"))
mco07_t9<- plm(data = data_table_9, formula = Financial_Conditions ~  RiskA + rating + WRate + Reserve_ratio + Sovereign.Debt + Private_Debt + Remunerated_Liabilities+External_Liabilities +others_BS+ factor(Year), model = "within", effect = "individual", index = c("name", "date"))


#Robust SE 
rse0_t9 <- robust_standard_errors(mco0_t9)
rse01_t9 <- robust_standard_errors(mco01_t9)
rse02_t9 <- robust_standard_errors(mco02_t9)
rse03_t9 <- robust_standard_errors(mco03_t9)
rse04_t9 <- robust_standard_errors(mco04_t9)
rse05_t9 <- robust_standard_errors(mco05_t9)
rse06_t9 <- robust_standard_errors(mco06_t9)
rse07_t9 <- robust_standard_errors(mco07_t9)


#Table9
stargazer(mco0_t9, mco01_t9, mco02_t9, mco03_t9, mco04_t9, mco05_t9, mco06_t9, mco07_t9, 
          type = "text", align = TRUE, se=list(rse0_t9, rse01_t9,rse02_t9, rse03_t9, rse04_t9, rse05_t9, rse06_t9, rse07_t9), 
          column.separate = c(1,4,5), 
          #covariate.labels = c("Risk Aversion", "Rating","World Rate","Reserve Ratio","Sovereign Debt","Private Debt", "Remunerated \\\\ Domestic Liabilites","Unsterilized \\\\ Purchases","Others  \\\\ Balance Sheet","External Liabilities"), 
          title = "Regresion results. Full Sample", omit="Year", 
          add.lines = list(c("Fixed effects?", "No", "Yes","Yes","Yes","Yes","Yes","Yes","Yes"),
                           c("Year dummies?","No","No","No","No","No","Yes","Yes","Yes")), 
          model.names = FALSE,digits = 2, column.sep.width = "-25pt", omit.stat = c("f","ser"))





######################################### Descriptive statistics table #####################3

#Auxiliar database
data_descriptive_table <-base_ely_aux %>% 
                                    filter(!is.na(spread),
                                                 !is.na(rating),
                                                 !is.na(RiskA),
                                                 !is.na(WRate),
                                                 !is.na(Reserve_ratio),
                                                 !is.na(Sovereign.Debt),
                                                 !is.na(Private_Debt)) %>% 
  mutate(spread=exp(spread),
        rating= exp(rating),
        RiskA=exp(RiskA),
        WRate=exp(WRate)) %>% 
  left_join(.,priv_debt_currency_comp,by=c("date","n")) %>% 
  left_join(.,Financial_conditions,by=c("date","n")) %>% 
  dplyr::select("Sovereign spread"=spread,
                "Credit Rating"=rating,
                "Reserves Ratio"=Reserve_ratio,
                "Sovereign Debt Ratio"=Sovereign.Debt,
                "Private Debt"=Private_Debt,
                "Risk Aversion"=RiskA,
                "10 Year US Treasury"=WRate,
                "Unsterilized Purchases"=Money,
                "Remunerated Liabilities Ratio"=Remunerated_Liabilities,
                "Priv. Debt currency comp."=foreign_ratio,
                "Financial Conditions"=Financial_Conditions)


format(mean(data_descriptive_table$`Credit Rating`,na.rm = TRUE),nsmall = 2)
#Variables of interest
variables_of_interest <- c("Sovereign spread",
                           "Credit Rating",
                           "Reserves Ratio",
                           "Sovereign Debt Ratio",
                           "Private Debt",
                           "Risk Aversion",
                           "10 Year US Treasury",
                           "Unsterilized Purchases",
                           "Remunerated Liabilities Ratio",
                           "Priv. Debt currency comp.",
                           "Financial Conditions")

#Final descriptive database
descriptive_statistics <- data.frame()
for(i in 1:length(variables_of_interest)){
  name_variable <- variables_of_interest[i]
  position <- as.numeric(grep(name_variable,variables_of_interest))
  descriptive_statistics[i,"Variable"]<- name_variable
  descriptive_statistics[i,"N"] <- sum(!is.na(data_descriptive_table[,position]))
  descriptive_statistics[i,"Mean"] <- format(mean(data_descriptive_table[,position],na.rm = TRUE),nsmall = 2)
  descriptive_statistics[i,"St. Dev"] <- format(sd(data_descriptive_table[,position],na.rm=TRUE),nsmall = 2)
  descriptive_statistics[i,"Min"] <- format(min(data_descriptive_table[,position],na.rm=TRUE),nsmall = 2)
  descriptive_statistics[i,"Median"] <- format(median(data_descriptive_table[,position],na.rm=TRUE),nsmall = 2)
  descriptive_statistics[i,"Max"] <- format(max(data_descriptive_table[,position],na.rm=TRUE),nsmall = 2)
  
}
descriptive_statistics
