#!/bin/bash
rm param.mod
$FC $F90FLAGS -O3 -s -o code_solve solve_indexed.f90 $LINK_FNL
code_solve
$FC $F90FLAGS -O3 -s -o code_sim sim_indexed.f90 $LINK_FNL
code_sim
matlab -nojvm -nodisplay -nosplash -r "run('get_moments'); exit;"