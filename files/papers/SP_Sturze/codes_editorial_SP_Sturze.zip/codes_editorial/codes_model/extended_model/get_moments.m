%% 0. Housekeeping
clear
close all
clc
load data_sim.txt
load def_per.txt
load def_per_ss.txt
load param.txt 
load param_delta.txt
load param_sigma.txt
load param_r_default.txt

indicator_print_all = -1;

clc
 

%% 1. Load simulated time-series
r = 0.04;
r_default = param_r_default/100;
delta = param_delta;
coupon = (r+delta)/(1+r);

per_num = param(1);  %HOW MANY PERIODS IN EACH SAMPLE
n = param(2);        %HOW MANY SAMPLES

y_t = zeros(per_num, n);
productivity = zeros(per_num, n);
bshort = zeros(per_num, n);
blong = zeros(per_num, n);
q = zeros(per_num, n);
c_t = zeros(per_num, n);
d = zeros(per_num, n);
excl = zeros(per_num, n);
b_long_next = zeros(per_num-1, n);
b_short_next = zeros(per_num-1, n);
duration = zeros(per_num,n);
market_access = zeros(per_num, n);
z = zeros(per_num, n);
wage = zeros(per_num, n);
labor = zeros(per_num, n);
rate = zeros(per_num, n);
loan = zeros(per_num, n);


for i=1:n
   y_t(:,i) = data_sim((i-1)*per_num+1:i*per_num,1); 
   productivity(:,i) = data_sim((i-1)*per_num+1:i*per_num,2); 
   bshort(:,i) = data_sim((i-1)*per_num+1:i*per_num,3); 
   blong(:,i) = data_sim((i-1)*per_num+1:i*per_num,4)*coupon/(1-(1-delta)*exp(-r)); %exp(-r)*(r+delta)/coupon; 
   blong1(:,i) = data_sim((i-1)*per_num+1:i*per_num,4);
   q(:,i) = data_sim((i-1)*per_num+1:i*per_num,5); 
   c_t(:,i) = data_sim((i-1)*per_num+1:i*per_num,6); 
   rate(:,i) = data_sim((i-1)*per_num+1:i*per_num,7);    
   tby(:,i) = data_sim((i-1)*per_num+1:i*per_num,8); 
   d(:,i) = data_sim((i-1)*per_num+1:i*per_num,9)-1;
   excl(:,i) = data_sim((i-1)*per_num+1:i*per_num,10); 
   %MARKET ACCESS INDICATOR = 1 ==> BAD, HIGH RISK PREMIUM
   %MARKET ACCESS INDICATOR = 0 ==> GOOD, LOW RISK PREMIUM
   market_access(:,i) = data_sim((i-1)*per_num+1:i*per_num,11)-1;
   duration(:,i) = (((1-delta).*q(:,i) +coupon)./(q(:,i)))./(((1-delta).*q(:,i) +coupon)./(q(:,i))-1+delta);
   z(:,i) = data_sim((i-1)*per_num+1:i*per_num,12); 
   wage(:,i) = data_sim((i-1)*per_num+1:i*per_num,13);    
   labor(:,i) = data_sim((i-1)*per_num+1:i*per_num,14);
   loan(:,i) = data_sim((i-1)*per_num+1:i*per_num,15);
   def_prob(:,i) = data_sim((i-1)*per_num+1:i*per_num,16);
   indices = find(blong(2:per_num,i)>-0.001);
end


for i=1:n
    for t=1:per_num-1
        b_short_next(t,i) = bshort(t+1,i);
        b_long_next(t,i) = blong(t+1,i);
    end
end


issuance = zeros(per_num, n);
res_accum = zeros(per_num, n);

for i_per = 1:per_num-1
    issuance(i_per,:) = blong1(i_per+1,:)-(1-d(i_per,:)).*(1-delta).*blong1(i_per,:);
    res_accum(i_per,:) = bshort(i_per+1,:)-bshort(i_per,:);
end


%% 2. Compute statistics for all sample periods.

num = per_num;
num_observations = n;
spread = (log(coupon./q - delta + 1) - r);

X_all = [ones(num,1) linspace(1,num,num)'];
y_t_trend_all = zeros(num, num_observations);
tby_trend_all = zeros(num, num_observations);
c_t_trend_all = zeros(num, num_observations);

for i=1:num_observations
    y_t_trend_all(:,i) = X_all*(X_all'*X_all)^(-1)*X_all'*log(y_t(:,i)); % hpfilter(last_y,lambda)';            
    c_t_trend_all(:,i) = X_all*(X_all'*X_all)^(-1)*X_all'*log(c_t(:,i)); %hpfilter(last_c, lambda)';           %FILTER log(consumption)
end

y_t_dev_all = log(y_t) - y_t_trend_all;
c_t_dev_all = log(c_t) - c_t_trend_all;
spread_dev_all = spread;

if indicator_print_all > 0
    
fprintf('Simulated moments for ALL samples \n')
fprintf('--------------------------------- \n')
fprintf(' \n')
fprintf('std of Yt                      = %6.2f \n',100*mean(std(y_t_dev_all)))
fprintf('std (Ct)/ std (Yt)             = %6.2f \n',mean(std(c_t_dev_all))/mean(std(y_t_dev_all)))
fprintf('std of R_s                     = %6.2f \n',100*mean(std(spread_dev_all)))

matrix_corr = zeros(num_observations,2);
matrix_corr_dres = zeros(num_observations,2);
matrix_corr_ddebt = zeros(num_observations,2);
matrix_corr_dres1 = zeros(num_observations,2);
matrix_corr_ddebt1 = zeros(num_observations,2);
matrix_corr_res = zeros(num_observations,2);
matrix_corr_debt = zeros(num_observations,2);

spread_noss = zeros(num_observations,1);
spread_ss = zeros(num_observations,1);

for i=1:num_observations    
    matrix = corrcoef([y_t_dev_all(:,i) c_t_dev_all(:,i) spread_dev_all(:,i) tby(:,i)  ]);
    matrix_corr_t_all(i,:) = matrix(1,2:4);
            
    matrix = corrcoef([bshort(2:num,i)./y_t(1:num-1,i) y_t_dev_all(1:num-1,i) spread_dev_all(1:num-1,i) blong(2:num,i)./y_t(1:num-1,i)]);
    matrix_corr_res_all(i,1) = matrix(1,2);
    matrix_corr_res_all(i,2) = matrix(1,3);
    matrix_corr_res_all(i,3) = matrix(1,4);
    
    matrix = corrcoef([blong(2:num,i)./y_t(1:num-1,i) y_t_dev_all(1:num-1,i) spread_dev_all(1:num-1,i)]);
    matrix_corr_debt_all(i,1) = matrix(1,2);
    matrix_corr_debt_all(i,2) = matrix(1,3);
    
    
   %MARKET ACCESS INDICATOR = 1 ==> BAD, HIGH RISK PREMIUM
   %MARKET ACCESS INDICATOR = 0 ==> GOOD, LOW RISK PREMIUM
    
    ind_ss_all = find(market_access(:,i)>0);
    ind_noss_all = find(market_access(:,i)<1);
    spread_noss_all(i) = mean(spread(ind_noss_all,i));
    spread_ss_all(i) = mean(spread(ind_ss_all,i));
end

ind_ss_all = (spread_ss_all>0);
fprintf('corr(tby, y)                   = %6.2f \n',mean(matrix_corr_t_all(:,3)))
fprintf('corr(c, y)                     = %6.2f \n',mean(matrix_corr_t_all(:,1)))
fprintf('corr(R_s,y)                    = %6.2f \n',mean(matrix_corr_t_all(:,2)))
fprintf('Annual mean default rate (all periods) = %6.2f \n', 100*mean(sum(d)/per_num))
fprintf('Mean (Debt/ Yt)                = %6.2f \n',100*mean(mean(blong./(y_t))))
fprintf('Mean (Res/ Yt)                 = %6.2f \n',100*mean(mean(bshort./(y_t))))
fprintf('Mean (Reserves/ Debt)          = %6.2f \n',100*mean(mean(bshort./blong)))
fprintf('E(R_s)                         = %6.2f \n',100*mean(mean(spread)))
fprintf('Max R_s                        = %6.2f \n',100*max(max(spread)))
fprintf('corr(res/Y, Y)                 = %6.2f \n',mean(matrix_corr_res_all(:,1)))
fprintf('corr(res/Y, Spread)            = %6.2f \n',mean(matrix_corr_res_all(:,2)))
fprintf('corr(res/Y, debt/Y)            = %6.2f \n',mean(matrix_corr_res_all(:,3)))
fprintf('corr(debt/Y, Y)                = %6.2f \n',mean(matrix_corr_debt_all(:,1)))
fprintf('corr(debt/Y, Spread)           = %6.2f \n',mean(matrix_corr_debt_all(:,2)))
fprintf('Duration                       = %6.2f \n',mean(mean(duration)))
%SELECT ONLY SAMPLES IN WHICH THERE ARE SUDDEN STOPS, I.E. THE SPREAD
%DURING SUDDEN STOP TAKES A POSITIVE NUMBER
fprintf('Extra spread during ss         = %6.2f \n',100*(mean(spread_ss_all(ind_ss_all))-mean(spread_noss_all(ind_ss_all))))

fprintf('Mean Labor                     = %6.2f \n',mean(mean(labor)))
fprintf('Mean Wage                      = %6.2f \n',mean(mean(wage)))
fprintf('Mean Loan                      = %6.2f \n',mean(mean(loan)))
fprintf('Mean Rate                      = %6.2f \n',mean(mean(rate)))
fprintf('Mean Def Prob 1-period ahead   = %6.4f \n',mean(mean(def_prob)))

%Now, compute some medians
fprintf('Median default rate (all periods)= %6.2f \n', 100*median(sum(d)/per_num))
fprintf('Median (Debt/ Yt)                = %6.2f \n',100*median(median(blong./(y_t))))
fprintf('Median (Res/ Yt)                 = %6.2f \n',100*median(median(bshort./(y_t))))
fprintf('Median (Reserves/ Debt)          = %6.2f \n',100*median(median(bshort./blong)))
fprintf('Median spread                    = %6.2f \n',100*median(median(spread)))
fprintf('Mean(Res)/mean(Debt)             = %6.2f \n',100*mean(mean(bshort))./mean(mean((blong))))
fprintf('Mean (Reserves/ ST liab.)        = %6.2f \n',100*nanmedian(nanmedian(bshort./(coupon*blong1))))
fprintf(' \n')
end
    

%% 3. Create No-Default subsamples (which are then reported in the paper)
num = 35; %HOW MANY PERIODS IN EACH SUBSAMPLE
indices = find(sum(d(per_num - num - 25 +1:per_num,:))<1); %LAST DEFAULT: 25 PERIODS BEFORE THE BEGINNING OF EACH SAMPLE.


num_observations = length(indices);
last_default = d(per_num - num+1:per_num, indices);  
last_y_t = y_t(per_num - num+1:per_num, indices);  
last_tby = tby(per_num - num+1:per_num, indices);  
last_productivity = productivity(per_num - num+1:per_num, indices);  
last_c_t = c_t(per_num - num+1:per_num, indices);  
last_wage = wage(per_num - num+1:per_num, indices);
last_labor = labor(per_num - num+1:per_num, indices);
last_rate = rate(per_num - num+1:per_num, indices); 
last_loan = loan(per_num - num+1:per_num, indices); 
last_q = q(per_num - num+1:per_num, indices); 
last_d = d(per_num - num+1:per_num, indices);
last_def_prob = def_prob(per_num - num+1:per_num, indices);
last_short = bshort(per_num - num+1:per_num, indices);
last_long = blong(per_num - num+1:per_num, indices);
last_long1 = blong1(per_num - num+1:per_num, indices);
last_spread = (log(coupon./q(per_num - num+1:per_num, indices) - delta + 1) - r);
last_market_access = market_access(per_num - num+1:per_num, indices);
last_duration = duration(per_num - num+1:per_num, indices);
last_issuance = issuance(per_num - num+1:per_num, indices);  
last_res_accum = res_accum(per_num - num+1:per_num, indices);


X = [ones(num,1) linspace(1,num,num)'];
y_t_trend = zeros(num, num_observations);
tby_trend = zeros(num, num_observations);
c_t_trend = zeros(num, num_observations);

for i=1:num_observations
    y_t_trend(:,i) = X*(X'*X)^(-1)*X'*log(last_y_t(:,i)); 
    c_t_trend(:,i) = X*(X'*X)^(-1)*X'*log(last_c_t(:,i)); 
end

y_t_dev = log(last_y_t) - y_t_trend;
c_t_dev = log(last_c_t) - c_t_trend;
spread_dev = last_spread;

matrix_corr_total = zeros(num_observations,3);
matrix_corr_t = zeros(num_observations,3);
matrix_corr_nt = zeros(num_observations,2);
matrix_corr_p_n = zeros(num_observations,2);
matrix_corr_dres = zeros(num_observations,2);
matrix_corr_ddebt = zeros(num_observations,2);
matrix_corr_dres1 = zeros(num_observations,2);
matrix_corr_ddebt1 = zeros(num_observations,2);
matrix_corr_res = zeros(num_observations,2);
matrix_corr_debt = zeros(num_observations,2);

spread_noss = zeros(num_observations,1);
spread_ss = zeros(num_observations,1);

for i=1:num_observations
    matrix = corrcoef([y_t_dev(:,i) c_t_dev(:,i) spread_dev(:,i) last_tby(:,i) ]);
    matrix_corr_t(i,:) = matrix(1,2:4);
        
    matrix = corrcoef([last_short(2:num,i)./last_y_t(1:num-1,i) y_t_dev(1:num-1,i) spread_dev(1:num-1,i) last_long(2:num,i)./last_y_t(1:num-1,i)]);
    matrix_corr_res(i,1) = matrix(1,2);
    matrix_corr_res(i,2) = matrix(1,3);
    matrix_corr_res(i,3) = matrix(1,4);
    
    matrix = corrcoef([last_long(2:num,i)./last_y_t(1:num-1,i) y_t_dev(1:num-1,i) spread_dev(1:num-1,i)]);
    matrix_corr_debt(i,1) = matrix(1,2);
    matrix_corr_debt(i,2) = matrix(1,3);
    
    matrix = corrcoef([spread_dev(:,i) last_rate(:,i)]);
    matrix_corr_rate(i,1) = matrix(1,2);
 
   
   %MARKET ACCESS INDICATOR = 1 ==> BAD, HIGH RISK PREMIUM
   %MARKET ACCESS INDICATOR = 0 ==> GOOD, LOW RISK PREMIUM
    
    ind_ss = find(last_market_access(:,i)>0);
    ind_noss = find(last_market_access(:,i)<1);
    spread_noss(i) = mean(last_spread(ind_noss,i));
    spread_ss(i) = mean(last_spread(ind_ss,i));
end

ind_ss = (spread_ss>0);


%% 4. Compute statistics only for No-Default subsamples

if indicator_print_all > 0
fprintf('Simulated moments for Pre-Default samples \n')
fprintf('----------------------------------------- \n')
fprintf(' \n')
fprintf('std of Yt                      = %6.2f \n',100*mean(std(y_t_dev)))
fprintf('std (Ct)/ std (Yt)             = %6.2f \n',mean(std(c_t_dev))/mean(std(y_t_dev)))
fprintf('std of R_s                     = %6.2f \n',100*mean(std(spread_dev)))

fprintf('corr(tby, y)                   = %6.2f \n',mean(matrix_corr_t(:,3)))
fprintf('corr(c, y)                     = %6.2f \n',mean(matrix_corr_t(:,1)))
fprintf('corr(R_s,y)                    = %6.2f \n',mean(matrix_corr_t(:,2)))
fprintf('Annual mean default rate (all periods) = %6.2f \n', 100*mean(sum(d)/per_num))
fprintf('Mean (Debt/ Yt)                = %6.2f \n',100*mean(mean(last_long./(last_y_t))))
fprintf('Mean (Debt) - level            = %6.5f \n',1*mean(mean(last_long1)))
fprintf('Mean (Res) - level             = %6.5f \n',1*mean(mean(last_short)))
fprintf('Mean (Res/ Yt)                 = %6.2f \n',100*mean(mean(last_short./(last_y_t))))
fprintf('Mean (Reserves/ Debt)          = %6.2f \n',100*mean(mean(last_short./last_long)))


fprintf('Mean (Issuance/ Debt)          = %6.2f \n',100*mean(mean(last_issuance./last_long)))
fprintf('Mean (Issuance/ Y)             = %6.2f \n',100*mean(mean(last_issuance./(last_y_t))))

fprintf('Median (Issuance/ Debt)        = %6.2f \n',100*median(median(last_issuance./last_long)))
fprintf('Median (Issuance/ Y )          = %6.2f \n',100*median(median(last_issuance./(last_y_t))))

fprintf('E(R_s)                         = %6.2f \n',100*mean(mean(last_spread)))
fprintf('Max R_s                        = %6.2f \n',100*max(max(last_spread)))

fprintf('corr(res/Y, Y )                = %6.2f \n',mean(matrix_corr_res(:,1)))
fprintf('corr(res/Y, Spread)            = %6.2f \n',mean(matrix_corr_res(:,2)))
fprintf('corr(res/Y, debt/Y             = %6.2f \n',mean(matrix_corr_res(:,3)))
fprintf('corr(debt/Y,Y                  = %6.2f \n',mean(matrix_corr_debt(:,1)))
fprintf('corr(debt/Y,Spread)            = %6.2f \n',mean(matrix_corr_debt(:,2)))
fprintf('corr(Rate, Spread)            = %6.2f \n',mean(matrix_corr_rate(:,1)))


fprintf('Duration                       = %6.2f \n',mean(mean(last_duration)))
%SELECT ONLY SAMPLES IN WHICH THERE ARE SUDDEN STOPS, I.E. THE SPREAD
%DURING SUDDEN STOP TAKES A POSITIVE NUMBER
fprintf('Extra spread during ss         = %6.2f \n',100*(mean(spread_ss(ind_ss))-mean(spread_noss(ind_ss))))

fprintf('Mean Labor                     = %6.4f \n',mean(mean(last_labor)))
fprintf('Mean Wage                      = %6.2f \n',mean(mean(last_wage)))
fprintf('Mean Loan                      = %6.4f \n',mean(mean(last_loan)))
fprintf('Mean Rate                      = %6.2f \n',mean(mean(last_rate)))

%Now, compute some medians
fprintf('Median default rate (all periods)= %6.2f \n', 100*median(sum(d)/per_num))
fprintf('Median (Debt/ Yt)                = %6.2f \n',100*median(median(last_long./(last_y_t))))
fprintf('Median (Res/ Yt)                 = %6.2f \n',100*median(median(last_short./(last_y_t))))
fprintf('Median (Reserves/ Debt)          = %6.2f \n',100*median(median(last_short./last_long)))
fprintf('Median spread                    = %6.2f \n',100*median(median(last_spread)))
fprintf('Mean(Res)/mean(Debt)             = %6.2f \n',100*mean(mean(last_short))./mean(mean((last_long))))
fprintf('Mean (Reserves/ ST liab.)       = %6.2f \n',100*mean(mean(last_short./(coupon*last_long1))))
fprintf('Median (Reserves/ ST liab.)     = %6.2f \n',100*median(median(last_short./(coupon*last_long1))))
fprintf(' \n')
end

%% 5. Print table B.2 (Simulated moments from the Model w/ Production)
% This replicates the (corresponding) model column in Table B2

fprintf('Simulated moments for Pre-Default samples in the Production Model \n')
fprintf('----------------------------------------------------------------- \n')
fprintf(' \n')
fprintf('Targeted \n')
fprintf('Mean debt (b/Y)                = %6.1f \n',100*mean(mean(last_long./(last_y_t))))
fprintf('Mean Spread (in percent)       = %6.1f \n',100*mean(mean(last_spread)))
fprintf('corr(Rate, Spread)             = %6.1f \n',mean(matrix_corr_rate(:,1)))
fprintf('Change in Rate in default      = %6.1f \n',100*(r_default-mean(mean(last_rate))))
fprintf('Extra spread during ss         = %6.1f \n',100*(mean(spread_ss(ind_ss))-mean(spread_noss(ind_ss))))
fprintf('std (c)/ std (Y)               = %6.2f \n',mean(std(c_t_dev))/mean(std(y_t_dev)))
fprintf('Non-Targeted \n')
fprintf('SD of Spread (in percent)      = %6.1f \n',100*mean(std(spread_dev)))
fprintf('corr(Spread,Y)                 = %6.1f \n',mean(matrix_corr_t(:,2)))
fprintf('corr(c, Y)                     = %6.2f \n',mean(matrix_corr_t(:,1)))
fprintf('Mean (Reserves/ Y)             = %6.1f \n',100*mean(mean(last_short./(last_y_t))))

