#!/bin/bash
#
#1) Compile the toolbox
gfortran -c -O3 -fopenmp -ffree-line-length-none toolbox.f90 -o toolbox.o
#2) Compile and build the program
gfortran -O3 -Wall -fcheck=all -g -fbacktrace -c solve_SP_STURZE_production.f90
gfortran -O3 -fopenmp toolbox.o solve_SP_STURZE_production.o -o code
#3) Run the code
./code